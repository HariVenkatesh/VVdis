vdis.accountPage.loadPage = function () {

    $("#lblVersion").html("VDIS JM ver " + AppVersion);

    if (localStorage.Account) {
        var loAccount = JSON.parse(localStorage.Account);
        $("#txtEmployeeID").val(loAccount.employee_id);
        $("#txtCompanyID").val(loAccount.company_id);
        $("#txtCompanyName2").val(loAccount.company_name);
        $("#txtAccountType2").val(loAccount.account_type);
        $(".hidden").show();
    }
    else {
        $("#btnAccountPageBack").hide();
    }
}

function onFocusOutEvent() {
    var getEmployeeIdOrEmail = document.getElementById("txtEmployeeID");
    
    var isEmail = getEmployeeIdOrEmail.value.indexOf("@");
    if (parseInt(isEmail) == -1) {
        getEmployeeIdOrEmail.value = getEmployeeIdOrEmail.value.toUpperCase();
    }
    else { getEmployeeIdOrEmail.value = getEmployeeIdOrEmail.value; }
}

$("#btnActivate").click(function () {
    // Validate required fields
    if ($("#txtEmployeeID").val().trim() == '') {
         messageBox.show("Employee ID or Email must be entered.", "Required");
         return;
    }
    if ($("#txtCompanyID").val().trim() == '') {
        messageBox.show("Company ID must be entered.", "Required");
        return;
    }
                        var lbReactivating = false;
                        if (localStorage.Account) {
                        lbReactivating = true;
                        }
    var loCompany_id = $("#txtCompanyID").val().trim().toUpperCase();
    if (loCompany_id in BaseServicesAddressDict) {
        localStorage.BaseServicesAddress = BaseServicesAddressDict[loCompany_id];
    } else {
        localStorage.BaseServicesAddress = BaseServicesAddressDict["LIVE"];
    };
                        var lnCheckEmailId=$("#txtEmployeeID").val().indexOf("@");
                        var loAccount = {
                        employee_id:(lnCheckEmailId==-1)?$("#txtEmployeeID").val().toUpperCase().trim():"",
                        email_address:(lnCheckEmailId==-1)?"":$("#txtEmployeeID").val().trim(),
                        company_id: $("#txtCompanyID").val().trim(),
                        device_type: device.platform
                        };
    $.mobile.loading("show", { text: "Activating....", textVisible: true });
    var lcApiUri = getApiUri("api/authentication/activate", true);
    $.ajax({
        type: "POST",
        url: lcApiUri,
        data: loAccount
    }).always(function () {
        $.mobile.loading("hide");
    }).done(function (data) {
        loAccount = data;
        localStorage.Account = JSON.stringify(loAccount);
        vdis.key = loAccount.authentication_key;
        delete vdis.ActiveJourneyID;
        delete vdis.ActiveJourney;
        delete localStorage.Employee;
        delete localStorage.EmployeeContacts;
        delete localStorage.Vehicle;
        delete localStorage.PreviousJourneys;
            //registerDevice(lbReactivating);
            location.reload(true);
            
    }).fail(function (xhr, status, error) {
        
        messageBox.show(getAjaxErrorMessage(xhr, status, error), "Activate");
         
    });

});  // btnActivate.click
