vdis.checkinPage.loadPage = function () {

    var moCurrentCheckin = {};

    var enableDisableButtons = function (enable) {
        if (enable) {
            $(".ui-btn").removeClass("ui-disabled");
        }
        else {
            $(".ui-btn").addClass("ui-disabled");
        }
    }

    var updateEta = function() {
        var liHours = parseInt($("#txtDurationHours").val());
        var liMinutes = parseInt($("#txtDurationMinutes").val());
        var liMinutesToArrival = liHours * 60 + liMinutes;
        var ldNow = new Date();
        var ldEta = ldNow.addMinutes(liMinutesToArrival);
        $("#txtRevisedEta").val(dateToDateTimeString(ldEta));
    }

    var noGeolocationResponse = function () {
        $.mobile.loading("hide");
        messageBox.show("Unable to get current position. Please enter your current position manually.", "Get Current Location");
        enableDisableButtons(true);
    }

    var loImmediateCheckinJourneyLog = {};

    if (!navigator.geolocation) {
        messageBox.show("Location services are not available in your browser. Please enter your current position manually.", "Current Location");
        enableDisableButtons(true);
    }

    $.mobile.loading("show");
    enableDisableButtons(false);

    var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);

    // get current location
    navigator.geolocation.getCurrentPosition(function (position) {
        clearTimeout(loWaitForLocationServices);
        $.mobile.loading("hide");
        $("#txtCheckinLatitude").val(position.coords.latitude);
        $("#txtCheckinLongitude").val(position.coords.longitude);

        //reverse geocode location
        var loLatLon = { lat: position.coords.latitude, lon: position.coords.longitude };
        var loGeocoder = L.mapbox.geocoder('mapbox.places');
        loGeocoder.reverseQuery(loLatLon, function (err, data) {
            enableDisableButtons(true);
            if (data) {
                $("#txtCheckinArea").val(getFormattedAddress(data));
            }
        });
    }, function (error) {
        clearTimeout(loWaitForLocationServices);
        $.mobile.loading("hide");
        var lcMessage = getCurrentPositionErrorMessage(error);
        messageBox.show(lcMessage, "Get Current Location");
    }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });

    // populate checkin drop down
    $("#ddnCheckinStatus").empty();
    if (vdis.ActiveCheckin.checkin_status == 0) {
        $("#ddnCheckinStatus").append("<option value='0'>Checkin</option>");
        $("#ddnCheckinStatus").append("<option value='1'>Standby</option>");
    }
    else {
        $("#ddnCheckinStatus").append("<option value='2'>Resume</option>");
    }
    $("#ddnCheckinStatus").selectmenu("refresh", true);

    //set ETA
    $("#txtRevisedEta").val(utcStringToDateTimeString(vdis.ActiveJourney.eta));

    //calculate duration
    var ldNow = new Date();
    var ldEta = new Date(vdis.ActiveJourney.eta);
    var liMinutesToArrival = ldNow.diffMinutes(ldEta)
    var liHours = Math.floor(liMinutesToArrival / 60.0);
    var liMinutes = liMinutesToArrival % 60;
    $("#txtDurationHours").val(liHours).slider("refresh");
    $("#txtDurationMinutes").val(liMinutes).slider("refresh");

    enableDisableButtons(true);

    $(".ui-slider-input").on("slidestop", function (e, ui) {
        updateEta();
    });
    $(".ui-slider-input").on("keyup", function (e, ui) {
        if (e.handled !== true) {
            e.handled = true;
            updateEta();
        }
    });


    $("#btnCalculateLatLon").click(function () {

        if (!$("#txtCheckinArea").val()) {
            messageBox.show("Address or city and province/state must be entered.", "Invalid");
            return;
        }

        $.mobile.loading("show");
        enableDisableButtons(false);

        // Geocode address
        var loGeocoder = L.mapbox.geocoder('mapbox.places');
        var lcAddress = $("#txtCheckinArea").val();
        loGeocoder.query(lcAddress, function (err, data) {
            $.mobile.loading("hide");
            enableDisableButtons(true);
            if (data.latlng) {
                $("#txtCheckinLatitude").val(data.latlng[0]);
                $("#txtCheckinLongitude").val(data.latlng[1]);
            }
            else {
                $("#txtCheckinLatitude").val("");
                $("#txtCheckinLongitude").val("");
            }
        });
    });


    $("#btnSubmit").click(function () {
        updateEta();                  
        //--- Validate
        //- required
        if ($("#txtCheckinArea").val().trim() == '') {
            messageBox.show("Address must be entered.", "Required");
            return;
        }
        if ($("#txtRevisedEta").val().trim() == '') {
            messageBox.show("ETA must be entered.", "Required");
            return;
        }
        
        //- invalid
        if (!isDate($("#txtRevisedEta").val())) {
            messageBox.show("ETA must be a valid date/time.", "Invalid");
            return;
        }
                          var ldRevisedEta = new Date($("#txtRevisedEta").val());
                          var ldNow = new Date();
                          if (ldRevisedEta.getTime() < ldNow.getTime()) {
                          messageBox.show("ETA must be a later than the current time.", "Invalid");
                          return;
                          }
                          if($("#ddnCheckinStatus").val()!="1"){
                          var ldRevisedEtaDate = new Date(ldRevisedEta);
                          var todayDate = new Date(ldNow);
                          var timesDifference = Math.abs(ldRevisedEtaDate.getTime() - todayDate.getTime());
                          var daysDifference = Math.ceil(timesDifference / (1000 * 3600 * 24));
                          var hoursDifference = (ldRevisedEtaDate - todayDate) / 3600000;

                          if(hoursDifference <1){
                          messageBox.show("Revise the ETA more than one hour to check in", "Required");
                          return;
                          }
                          }
                          
                      

        var lnLatitude, lnLongitude;
        if ($("#txtCheckinLatitude").val().trim() != '' && $("#txtCheckinLongitude").val().trim() != '') {
            lnLatitude = parseFloat($("#txtCheckinLatitude").val());
            if (isNaN(lnLatitude)) {
                messageBox.show("Latitude must be a valid decimal value.", "Invalid");
                return;
            }
            lnLongitude = parseFloat($("#txtCheckinLongitude").val());
            if (isNaN(lnLongitude)) {
                messageBox.show("Longitude must be a valid decimal value.", "Invalid");
                return;
            }
            if (lnLatitude > 90 || lnLatitude < -90) {
                messageBox.show("Latitude must be between -90 and 90.", "Invalid");
                return;
            }
            if (lnLongitude > 180 || lnLongitude < -180) {
                messageBox.show("Longitude must be between -180 and 180.", "Invalid");
                return;
            }
        }


        // Commit Controls
        moCurrentCheckin.checkin_area = $("#txtCheckinArea").val();
        if ($("#txtCheckinLatitude").val().trim() != '' && $("#txtCheckinLongitude").val().trim() != '') {
            moCurrentCheckin.latitude = lnLatitude;
            moCurrentCheckin.longitude = lnLongitude;
        }
        else {
            moCurrentCheckin.latitude = null;
            moCurrentCheckin.longitude = null;
        }
        moCurrentCheckin.checkin_status = parseInt($("#ddnCheckinStatus").val());

        var lcRevisedEtaUtc = "";
        var ldEta = new Date(vdis.ActiveJourney.eta);
        if (ldRevisedEta.getTime() != ldEta.getTime()) {
            lcRevisedEtaUtc = dateToUtcString(ldRevisedEta);
        }


        // Save
        enableDisableButtons(false);
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/checkin");
        lcApiUri += "&revisedEta=" + lcRevisedEtaUtc
        $.ajax({
            type: "POST",
            url: lcApiUri,
            data: moCurrentCheckin
        }).always(function () {
            $.mobile.loading("hide");
            enableDisableButtons(true);
        }).done(function () {
            vdis.ActiveJourney.eta = lcRevisedEtaUtc;
            messageBox.show("Successfully checked in.", "Checkin",
                function (okPressed) {
                    SetButtonVisibility();
                     $.mobile.back();
                }, false);
        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Checkin");
        });

    });
}
