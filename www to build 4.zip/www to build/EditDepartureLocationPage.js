﻿vdis.editDepartureLocationPage.loadPage = function () {

    var moJourney = vdis.newJourneyPage.data;

    var enableDisableButtons = function (enable) {
        if (enable) {
            $(".ui-btn").removeClass("ui-disabled");
        }
        else {
            $(".ui-btn").addClass("ui-disabled");
        }
    }

    var populateFields = function () {
        $("#txtDepartureArea").val(moJourney.departure_area || "");
        if (moJourney.departure_latitude && moJourney.departure_longitude) {
            $("#txtDepartureLatitude").val(moJourney.departure_latitude.toFixed(4));
            $("#txtDepartureLongitude").val(moJourney.departure_longitude.toFixed(4));
        }
    }

    // --- main ---


    populateFields();


    // --- event handlers ---


    $("#btnCalculateLatLon").click(function () {

        if (!$("#txtDepartureArea").val()) {
            messageBox.show("Address or city and province/state must be entered.", "Invalid");
            return;
        }

        $.mobile.loading("show");
        enableDisableButtons(false);

        // Geocode address
        var loGeocoder = L.mapbox.geocoder('mapbox.places');
        var lcAddress = $("#txtDepartureArea").val();
        loGeocoder.query(lcAddress, function (err, data) {
            $.mobile.loading("hide");
            enableDisableButtons(true);
            if (data.latlng) {
                $("#txtDepartureLatitude").val(data.latlng[0]);
                $("#txtDepartureLongitude").val(data.latlng[1]);
            }
            else {
                $("#txtDepartureLatitude").val("");
                $("#txtDepartureLongitude").val("");
            }
        });

    });

    $("#btnSaveDepartureLocation").click(function () {

        // Validate

        if ($("#txtDepartureLatitude").val() || $("#txtDepartureLongitude").val()) {

            var lnLatitude = parseFloat($("#txtDepartureLatitude").val());
            if (isNaN(lnLatitude)) {
                messageBox.show("Latitude must be a valid decimal value.", "Invalid");
                return;
            }
            var lnLongitude = parseFloat($("#txtDepartureLongitude").val());
            if (isNaN(lnLongitude)) {
                messageBox.show("Longitude must be a valid decimal value.", "Invalid");
                return;
            }
            if (lnLatitude > 90 || lnLatitude < -90) {
                messageBox.show("Latitude must be between -90 and 90.", "Invalid");
                return;
            }
            if (lnLongitude > 180 || lnLongitude < -180) {
                messageBox.show("Longitude must be between -180 and 180.", "Invalid");
                return;
            }

            moJourney.departure_latitude = lnLatitude;
            moJourney.departure_longitude = lnLongitude;

        }
        else {
            moJourney.departure_latitude = null;
            moJourney.departure_longitude = null;
        }

        moJourney.departure_area = $("#txtDepartureArea").val();

        vdis.newJourneyPage.data = moJourney;
        $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
//        $.mobile.back();
                                         

    });
}

