﻿vdis.editDestinationLocationPage.loadPage = function () {

    var moJourney = vdis.newJourneyPage.data;

    var enableDisableButtons = function (enable) {
        if (enable) {
            $(".ui-btn").removeClass("ui-disabled");
        }
        else {
            $(".ui-btn").addClass("ui-disabled");
        }
    }

    var populateFields = function () {
        $("#txtDestinationArea").val(moJourney.destination_area || "");
        if (moJourney.destination_latitude && moJourney.destination_longitude) {
            $("#txtDestinationLatitude").val(moJourney.destination_latitude.toFixed(4));
            $("#txtDestinationLongitude").val(moJourney.destination_longitude.toFixed(4));
        }
    }

    // --- main ---


    populateFields();


    // --- event handlers ---


    $("#btnCalculateLatLon").click(function () {

        if (!$("#txtDestinationArea").val()) {
            messageBox.show("Address or city and province/state must be entered.", "Invalid");
            return;
        }

        $.mobile.loading("show");
        enableDisableButtons(false);

        // Geocode address
        var loGeocoder = L.mapbox.geocoder('mapbox.places');
        var lcAddress = $("#txtDestinationArea").val();
        loGeocoder.query(lcAddress, function (err, data) {
            $.mobile.loading("hide");
            enableDisableButtons(true);
            if (data.latlng) {
                $("#txtDestinationLatitude").val(data.latlng[0]);
                $("#txtDestinationLongitude").val(data.latlng[1]);
            }
            else {
                $("#txtDestinationLatitude").val("");
                $("#txtDestinationLongitude").val("");
            }
        });
    }); 

    $("#btnSaveDestinationLocation").click(function () {

        // Validate

if($("#txtDestinationArea").val()==""){
$("#txtDestinationLatitude").val("");
$("#txtDestinationLongitude").val("");
 }

        if ($("#txtDestinationLatitude").val() || $("#txtDestinationLongitude").val()) {

            var lnLatitude = parseFloat($("#txtDestinationLatitude").val());




            if (isNaN(lnLatitude)) {
                messageBox.show("Latitude must be a valid decimal value.", "Invalid");
                return;
            }
            var lnLongitude = parseFloat($("#txtDestinationLongitude").val());
            if (isNaN(lnLongitude)) {
                messageBox.show("Longitude must be a valid decimal value.", "Invalid");
                return;
            }
            if (lnLatitude > 90 || lnLatitude < -90) {
                messageBox.show("Latitude must be between -90 and 90.", "Invalid");
                return;
            }
            if (lnLongitude > 180 || lnLongitude < -180) {
                messageBox.show("Longitude must be between -180 and 180.", "Invalid");
                return;
            }

            moJourney.destination_latitude = lnLatitude;
            moJourney.destination_longitude = lnLongitude;

        }
        else {
            moJourney.destination_latitude = null;
            moJourney.destination_longitude = null;
        }

        moJourney.destination_area = $("#txtDestinationArea").val();

        vdis.newJourneyPage.data = moJourney;
        $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
                                           
//        $.mobile.back();

    });
}

