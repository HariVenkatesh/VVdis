﻿vdis.editEmergencyContactPage.loadPage = function () {

    var deleteRecord = function (okPressed) {

        if (okPressed == true) {
            $.mobile.loading("show");
            var loEmergencyContact = vdis.editEmergencyContactPage.data;
            var lcApiUri = getApiUri("api/employees/contacts/" + loEmergencyContact.rec_id);
            $.ajax({
                type: "DELETE",
                url: lcApiUri
            }).always(function () {
                $.mobile.loading("hide");
            }).done(function () {
                $.mobile.back();
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Delete Employee Contact");
            });
        }

    }

    var populateEmployeeContactFields = function () {
        var loEmergencyContact = vdis.editEmergencyContactPage.data;
        $("#txtContactName").val(loEmergencyContact.contact_name);
        $("#ddnPhoneType").val(loEmergencyContact.phone_type_1);
        $("#txtPhoneNumber").val(loEmergencyContact.phone_number_1);
        $("#ddnPhoneType").selectmenu("refresh");
    }

    populateEmployeeContactFields();

    if (vdis.editEmergencyContactPage.editMode == "New") {
        $("#btnDelete").addClass("hidden");
    }
    else {
        $("#btnDelete").removeClass("hidden");
    }

    $("#btnSaveEmergencyContact").click(function () {

        // Validate required fields
        if ($("#txtContactName").val().trim() == '') {
            messageBox.show("Contact Name must be entered.", "Required");
            return;
        }
        if ($("#txtPhoneNumber").val().trim() == '') {
            messageBox.show("Phone Number must be entered.", "Required");
            return;
        }

        // Commit Controls
        var loEmergencyContact = vdis.editEmergencyContactPage.data;
        if (loEmergencyContact.contact_name != $("#txtContactName").val() ||
                loEmergencyContact.phone_type_1 != $("#ddnPhoneType").val() ||
                loEmergencyContact.phone_number_1 != $("#txtPhoneNumber").val()) {
            loEmergencyContact.contact_name = $("#txtContactName").val();
            loEmergencyContact.phone_type_1 = $("#ddnPhoneType").val();
            loEmergencyContact.phone_number_1 = $("#txtPhoneNumber").val();

            // Save
            $.mobile.loading("show");
            var lcApiUri = getApiUri("api/employees/contacts");
            $.ajax({
                type: (vdis.editEmergencyContactPage.editMode == "New" ? "POST" : "PUT"),
                url: lcApiUri,
                data: loEmergencyContact
            }).always(function () {
                $.mobile.loading("hide");
            }).done(function () {
                $.mobile.back();
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Save Employee Contact");
            });
        }
        else {
            $.mobile.back();
        }
    });

    $("#btnDelete").click(function () {

        messageBox.show("Delete this record?", "Confirm", deleteRecord, true);

    });
}

