vdis.indexPage.loadPage = function () {
    
    var miAsyncOperationCount = 0
    
    var populateEmployeeFields = function () {
        var loEmployee = JSON.parse(localStorage.Employee);
        var lcEmployeeName = loEmployee.first_name + " " + loEmployee.last_name;
        $("#lblEmployeeName").html(lcEmployeeName);
    }
    
    
    // grab the AppVersion.json file using ajax and compare with AppVersion variable to see if
    // the page needs to be reloaded (we are viewing a cached version)
    var checkAppVersion = function () {
        var noCache = new Date().getTime();
        $.getJSON("Scripts/appConfig.json", { "noCache": noCache })
        .done(function (data) {
              if (data.appVersion != AppVersion) {
              //reload the page
              location.reload(true);
              }
              }).fail(function (xhr, status, error) {
                      messageBox.show(getAjaxErrorMessage(xhr, status, error), "Check App Version");
                      });
    }
    
    var sameDayTime = function (currentTime, previousTime) {
        if (isDate(currentTime) && isDate(previousTime)) {
            var ldCurrent = new Date(currentTime);
            var ldPrevious = new Date(previousTime);
            // JavaScript will return false for ldCurrent == ldPrevious because they are different objects, so compare components
            if (ldCurrent.getFullYear() == ldPrevious.getFullYear() && ldCurrent.getMonth() == ldPrevious.getMonth() && ldCurrent.getDate() == ldPrevious.getDate()) {
                return dateToTimeString(ldCurrent);
            }
            else {
                return dateToDateTimeString(ldCurrent);
            }
        }
        else {
            return "";
        }
    }
    
    var statusIdToName = function (statusID) {
        switch (statusID) {
            case CheckinStatus:
                return "Check-in";
            case StandbyStatus:
                return "Stand-by";
            case ResumeStatus:
                return "Resume";
            default:
                return "";
        }
    }
    
    // get Me data
    var getEmployee = function () {
        if (localStorage.Employee) {
            populateEmployeeFields();
        }
        else {
            // user can only access own employee record
            var lcApiUri = getApiUri("api/employees");
            $.getJSON(lcApiUri)
            .done(function (data) {
                  localStorage.Employee = JSON.stringify(data);
                  populateEmployeeFields();
                  }).fail(function (xhr, status, error) {
                          messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee");
                          });
        }
    }
    
    // get employee contacts
    var getEmployeeContacts = function () {
        if (!localStorage.EmployeeContacts) {
            // user can only access own employee contact records
            var lcApiUri = getApiUri("api/employees/contacts");
            $.getJSON(lcApiUri)
            .done(function (data) {
                  localStorage.EmployeeContacts = JSON.stringify(data);
                  }).fail(function (xhr, status, error) {
                          messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee Contacts");
                          });
        }
    }
    
    
    var getActiveCheckinStatus = function () {
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/checkinstatus");
        $.getJSON(lcApiUri)
        .done(function (data) {
              vdis.ActiveCheckin = { checkin_status: parseInt(data) };
              }).fail(function (xhr, status, error) {
                      messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Checkin Status");
                      });
    }
    // get active journey ID
    var getActiveJourneyID = function () {
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/journeys/active/journeyid");
        $.getJSON(lcApiUri)
        .done(function (data) {
              if (data) {
              vdis.ActiveJourneyID = data;
              getJourneyRecord();
              $("#btnJourneyHome").text("Current Journey");
              $("#btnJourneyHome").css("visibility", "visible");
              $("#btnJourneyHome").css("display", "block");
              
              $("#btnWorkAlonePeriod").text("New Work Alone Session");
              $("#btnWorkAlonePeriod").css("visibility", "visible");
              $("#btnWorkAlonePeriod").css("display", "block");
              $("#btnWorkAlonePeriod").hide();
              
              $("#btnPreviousHome").text("Check In");
              $("#btnPreviousHome").css("visibility", "visible");
              $("#btnPreviousHome").css("display", "block");
              $("#btnArrivedHome").css("visibility", "visible");
              $("#btnArrivedHome").css("display", "block");
              $("#btnMap").css("visibility", "visible");
              $("#btnMap").css("display", "block");
              $("#btnMessages").css("visibility", "visible");
              $("#btnMessages").css("display", "block");
              $("#btnMyProfile").css("visibility", "visible");
              $("#btnMyProfile").css("display", "block");
              getActiveCheckinStatus();
              }
              else {
              vdis.ActiveJourneyID = 0; //indicates that there is no active journey
              $("#btnJourneyHome").text("New Journey");
              $("#btnJourneyHome").css("visibility", "visible");
              $("#btnJourneyHome").css("display", "block");
              
              $("#btnWorkAlonePeriod").show();
              $("#btnWorkAlonePeriod").text("New Work Alone Session");
              $("#btnWorkAlonePeriod").css("visibility", "visible");
              $("#btnWorkAlonePeriod").css("display", "block");
              
              
              $("#btnPreviousHome").text("Previous Journey");
              $("#btnPreviousHome").css("visibility", "visible");
              $("#btnPreviousHome").css("display", "block");
              $("#btnArrivedHome").css("visibility", "hidden");
              $("#btnArrivedHome").css("display", "none");
              $("#btnMap").css("visibility", "hidden");
              $("#btnMap").css("display", "none");
              $("#btnMessages").css("visibility", "visible");
              $("#btnMessages").css("display", "block");
              $("#btnMyProfile").css("visibility", "visible");
              $("#btnMyProfile").css("display", "block");
              }
              $.mobile.loading("hide");
              }).fail(function (xhr, status, error) {
                      $.mobile.loading("hide");
                      messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Journey ID");
                      });
    }
    
    // get journey record
    var getJourneyRecord = function () {
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID);
        $.getJSON(lcApiUri)
        .done(function (data) {
              vdis.ActiveJourney = data;
              localStorage.ActiveJourney = JSON.stringify(vdis.ActiveJourney);
              
              getJourneyLogItems();
              }).fail(function (xhr, status, error) {
                      $.mobile.loading("hide");
                      messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Journey Record");
                      });
    }
    var getJourneyLogItems = function () {
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/log");
        $.getJSON(lcApiUri)
        .done(function (data) {
              populateLogFields(data);
              miAsyncOperationCount -= 1;
              if (miAsyncOperationCount == 0) {
              $.mobile.loading("hide");
              }
              }).fail(function (xhr, status, error) {
                      $.mobile.loading("hide");
                      messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Journey Log");
                      });
    }
    var populateLogFields = function (logRecs) {
        
        var lcolJourneyLogRecs = logRecs;
        
        //-- create journey log presentation items
        
        var lcolJourneyLogItems = [];
        var loJourneyLogItem = {};
        
        //Departure
        loJourneyLogItem.Status = "Departure";
        loJourneyLogItem.Area = vdis.ActiveJourney.departure_area || "";
        loJourneyLogItem.Time = utcStringToDateTimeString(vdis.ActiveJourney.departure_datetime);
        if (vdis.ActiveJourney.departure_latitude && vdis.ActiveJourney.departure_longitude) {
            loJourneyLogItem.LatLon = vdis.ActiveJourney.departure_latitude.toFixed(4) + ", " + vdis.ActiveJourney.departure_longitude.toFixed(4);
        }
        else {
            loJourneyLogItem.LatLon = "";
        }
        lcolJourneyLogItems[0] = loJourneyLogItem;
        
        //Check-ins
        var ldPrevLogRecTime = new Date(vdis.ActiveJourney.departure_datetime);
        $.each(lcolJourneyLogRecs, function (i, loJourneyLogRec) {
               loJourneyLogItem = {};
               loJourneyLogItem.Status = statusIdToName(loJourneyLogRec.checkin_status);
               loJourneyLogItem.Area = loJourneyLogRec.checkin_area || "";
               //use actual time if entered, otherwise use tentative due time
               if (loJourneyLogRec.checkin_actual_time) {
               var ldCheckinActual = new Date(loJourneyLogRec.checkin_actual_time);
               loJourneyLogItem.Time = sameDayTime(ldCheckinActual, ldPrevLogRecTime);
               ldPrevLogRecTime = ldCheckinActual;
               }
               else {
               var ldCheckinDue = new Date(loJourneyLogRec.checkin_due_time);
               loJourneyLogItem.Time = "? " + sameDayTime(ldCheckinDue, ldPrevLogRecTime);
               ldPrevLogRecTime = ldCheckinDue;
               }
               if (loJourneyLogRec.latitude && loJourneyLogRec.longitude) {
               loJourneyLogItem.LatLon = loJourneyLogRec.latitude.toFixed(4) + ", " + loJourneyLogRec.longitude.toFixed(4);
               }
               else {
               loJourneyLogItem.LatLon = "";
               }
               lcolJourneyLogItems.push(loJourneyLogItem);
               });
        vdis.ActiveCheckin = lcolJourneyLogRecs[lcolJourneyLogRecs.length - 1];
        
        //Tentative Check-ins
        var ldTentativeCheckinTime = new Date(0);
        if (!vdis.ActiveJourney.actual_arrival_datetime) {
            var ldEta = new Date(vdis.ActiveJourney.eta)
            var liMinutesToDestination = ldPrevLogRecTime.diffMinutes(ldEta);
            var liTentativeCheckinCount = parseInt(liMinutesToDestination / vdis.ActiveJourney.checkin_interval);
            if (liTentativeCheckinCount > 250) {
                lcolJourneyLogItems.push({ Area: "TOO MANY POINTS", Status: "", Time: "", LatLon: "" });
            }
            else {
                for (i = 1; i <= liTentativeCheckinCount; i++) {
                    ldTentativeCheckinTime = ldPrevLogRecTime.addMinutes(vdis.ActiveJourney.checkin_interval);
                    lcolJourneyLogItems.push({
                                             Time: "? " + sameDayTime(ldTentativeCheckinTime, ldPrevLogRecTime),
                                             Status: "",
                                             Area: "",
                                             LatLon: ""
                                             });
                    ldPrevLogRecTime = ldTentativeCheckinTime;
                }
            }
        }
        
        //Destination
        loJourneyLogItem = {};
        loJourneyLogItem.Status = "Destination";
        loJourneyLogItem.Area = vdis.ActiveJourney.destination_area || "";
        if (vdis.ActiveJourney.actual_arrival_datetime) {
            var ldActualArrival = new Date(vdis.ActiveJourney.actual_arrival_datetime)
            loJourneyLogItem.Time = sameDayTime(ldActualArrival, ldPrevLogRecTime);
        }
        else {
            var ldEta = new Date(vdis.ActiveJourney.eta)
            loJourneyLogItem.Time = "? " + sameDayTime(ldEta, ldPrevLogRecTime);
        }
        if (vdis.ActiveJourney.destination_latitude && vdis.ActiveJourney.destination_longitude) {
            loJourneyLogItem.LatLon = vdis.ActiveJourney.destination_latitude.toFixed(4) + ", " + vdis.ActiveJourney.destination_longitude.toFixed(4);
        }
        else {
            loJourneyLogItem.LatLon = "";
        }
        lcolJourneyLogItems.push(loJourneyLogItem);
        
    }
    
    
    var closeJourneyImmediately = function () {
        var loImmediateCloseData = {
        destination_latitude: null,
        destination_longitude: null
        };
        
        
        this.noGeolocationResponse = function () {
            $.mobile.loading("hide");
            // $("#btnImmediateArrived").removeClass("ui-btn-active");
            messageBox.show("Unable to get current position. Closing to booked destination without coordinates.", "Get Current Location",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            },true);
        }
        
        if (!navigator.geolocation) {
            messageBox.show("Unable to get current position. Closing to booked destination without coordinates.", "Get Current Location",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            },true);
            return;
        }
        
        $.mobile.loading("show");
        
        var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);
        
        // get current location
        navigator.geolocation.getCurrentPosition(function (position) {
                                                 clearTimeout(loWaitForLocationServices);
                                                 loImmediateCloseData.destination_latitude = position.coords.latitude;
                                                 loImmediateCloseData.destination_longitude = position.coords.longitude;
                                                 confirmClose();
                                                 }, function (error) {
                                                 
                                                 clearTimeout(loWaitForLocationServices);
                                                 $.mobile.loading("hide");
                                                 var lcMessage = getCurrentPositionErrorMessage(error) + " Closing to booked destination without coordinates.";
                                                 messageBox.show(lcMessage, "Get Current Location",
                                                                 function (okPressed) {
                                                                 if(okPressed){
                                                                 closeJourney();
                                                                 }
                                                                 },true);
                                                 
                                                 }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });
        
        this.confirmClose = function () {
            
            $.mobile.loading("hide");
            messageBox.show("Close journey using current location?", "Confirm",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            },true);
        }
        
        this.closeJourney = function () {
            
            $.mobile.loading("show");
            var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/close");
            $.ajax({
                   type: "POST",
                   url: lcApiUri,
                   data: loImmediateCloseData
                   }).always(function () {
                             $.mobile.loading("hide");
                             
                             }).done(function () {
                                     
                                     var ldNow = new Date();
                                     // save to previous journeys list
                                     
                                     vdis.ActiveJourney.actual_arrival_datetime = dateToUtcString(ldNow);
                                     
                                     lcolPreviousJourneys = [];
                                     if (localStorage.PreviousJourneys) {
                                     lcolPreviousJourneys = JSON.parse(localStorage.PreviousJourneys);
                                     }
                                     vdis.ActiveJourney.IsFavorite = false;
                                     
                                     lcolPreviousJourneys.insert(0, vdis.ActiveJourney);
                                     
                                     if (lcolPreviousJourneys.length > 20) {
                                     for (i = lcolPreviousJourneys.length - 1; i >= 20; i--) {
                                     var loPrevJourney = lcolPreviousJourneys[i];
                                     if (!loPrevJourney.IsFavorite) {
                                     lcolPreviousJourneys.removeAt(i)
                                     }
                                     }
                                     }
                                     localStorage.PreviousJourneys = JSON.stringify(lcolPreviousJourneys);
                                     // reset active journey data
                                     vdis.ActiveJourneyID = 0;
                                     vdis.ActiveJourney = null;
                                     vdis.ActiveCheckin = null;
                                     // finish up
                                     messageBox.show("Journey successfully closed.", "Close Journey",
                                                     function (okPressed) {
                                                     
                                                     vdis.ActiveJourneyID = 0; //indicates that there is no active journey
                                                     $("#btnJourneyHome").text("New Journey");
                                                     $("#btnJourneyHome").css("visibility", "visible");
                                                     $("#btnJourneyHome").css("display", "block");
                                                     
                                                     $("#btnWorkAlonePeriod").show();
                                                     $("#btnWorkAlonePeriod").text("New Work Alone Session");
                                                     $("#btnWorkAlonePeriod").css("visibility", "visible");
                                                     $("#btnWorkAlonePeriod").css("display", "block");
                                                     
                                                     
                                                     $("#btnPreviousHome").text("Previous Journey");
                                                     $("#btnPreviousHome").css("visibility", "visible");
                                                     $("#btnPreviousHome").css("display", "block");
                                                     $("#btnArrivedHome").css("visibility", "hidden");
                                                     $("#btnArrivedHome").css("display", "none");
                                                     $("#btnMap").css("visibility", "hidden");
                                                     $("#btnMap").css("display", "none");
                                                     $("#btnMessages").css("visibility", "visible");
                                                     $("#btnMessages").css("display", "block");
                                                     $("#btnMyProfile").css("visibility", "visible");
                                                     $("#btnMyProfile").css("display", "block");
                                                     }, false);
                                     }).fail(function (xhr, status, error) {
                                             messageBox.show(getAjaxErrorMessage(xhr, status, error), "Close Journey");
                                             });
        }
    }
    
    //--- main ---
    
    
    checkAppVersion();
    getEmployee();
    getEmployeeContacts();
    SetButtonVisibility();
    getActiveJourneyID();
	getLogoImage();
    //--- event handlers ---
    
    $("#btnJourneyHome").click(function (e) {
                               
                               if (e.handled !== true) {
                               e.handled = true;
                               if (vdis.ActiveJourneyID) {
                               $.mobile.pageContainer.pagecontainer("change", "JourneyPage.html");
                               }
                               else {
                               vdis.newJourneyPage.data = {};
                               $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
                               }
                               }
                               });
    
    
    
    $("#btnWorkAlonePeriod").click(function (e) {
                               
                               if (e.handled !== true) {
                               e.handled = true;
                               if (vdis.ActiveJourneyID) {
                               //$.mobile.pageContainer.pagecontainer("change", "JourneyPage.html");
                               }
                               else {
                               vdis.newJourneyPage.data = {};
                               $.mobile.pageContainer.pagecontainer("change", "NewWorkAloneSessionPage.html");
                               }
                               }
                               });
    
    
    
    
    
    $("#btnPreviousHome").click(function (e) {
                                
                                if (e.handled !== true) {
                                e.handled = true;
                                if ($(this).html() == "Previous Journey") {
                                if (vdis.ActiveJourneyID == 0) {
                                vdis.previousJourneysPage.selectionMode = "Normal";
                                $.mobile.pageContainer.pagecontainer("change", "PreviousJourneysPage.html");
                                }
                                }
                                else {
                                //If the button text is "Check in" redirect to CheckinPage
                                $.mobile.pageContainer.pagecontainer("change", "CheckinPage.html");
                                
                                }
                                }
                                
                                
                                });
    
    $("#btnMyProfile").click(function (e) {
                             
                             if (e.handled !== true) {
                             e.handled = true;
                             if ($(this).html() == "My Profile") {
                             $.mobile.pageContainer.pagecontainer("change", "MyProfilePage.html");
                             }
                             }
                             });
    
    $("#btnArrivedHome").click(function (e) {
                               
                               if (e.handled !== true) {
                               e.handled = true;
                               closeJourneyImmediately();
                               }
                               });
    
    $("#btnMap").click(function (e) {
                       
                       if (e.handled !== true) {
                       e.handled = true;
                       $.mobile.pageContainer.pagecontainer("change", "MapPage.html");
                       }
                       
                       });
    
    $("#btnMessages").click(function (e) {
                            
                            if (e.handled !== true) {
                            e.handled = true;
                            $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
                            }
                            
                            });
}


