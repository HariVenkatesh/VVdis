vdis.journeyPage.loadPage = function () {
    var miAsyncOperationCount = 0

    var enableDisableButtons = function(enable) {
        if (enable) {
            $(".journeyPageToolbar a,input[type=button]").removeClass("ui-disabled");
        }
        else {
            $(".journeyPageToolbar a,input[type=button]").addClass("ui-disabled");
        }
    }

    var sameDayTime = function (currentTime, previousTime) {
        if (isDate(currentTime) && isDate(previousTime)) {
            var ldCurrent = new Date(currentTime);
            var ldPrevious = new Date(previousTime);
            // JavaScript will return false for ldCurrent == ldPrevious because they are different objects, so compare components
            if (ldCurrent.getFullYear() == ldPrevious.getFullYear() && ldCurrent.getMonth() == ldPrevious.getMonth() && ldCurrent.getDate() == ldPrevious.getDate()) {
                return dateToTimeString(ldCurrent);
            }
            else {
                return dateToDateTimeString(ldCurrent);
            }
        }
        else {
            return "";
        }
    }

    var statusIdToName = function (statusID) {
        switch (statusID) {
            case CheckinStatus:
                return "Check-in";
            case StandbyStatus:
                return "Stand-by";
            case ResumeStatus:
                return "Resume";
            default:
                return "";
        }
    }

    var populateJourneyFields = function () {

        // Summary
        var loJourney = vdis.ActiveJourney;
        $("#txtJourneyID").val(padNumericID(loJourney.journey_id, 8));  //zero padded
        var lcDeparture = loJourney.departure_area + "<br />" + utcStringToDateTimeString(loJourney.departure_datetime)
        if (loJourney.departure_latitude && loJourney.departure_longitude) {
            lcDeparture += "&nbsp;&nbsp;&nbsp;&nbsp;(" + loJourney.departure_latitude.toFixed(4) + ", " + loJourney.departure_longitude.toFixed(4) + ")</span>"
        }
        $("#txtDeparture").html(lcDeparture);
        var lcDestination = loJourney.destination_area + "<br />" + utcStringToDateTimeString(loJourney.eta)
        if (loJourney.destination_latitude && loJourney.destination_longitude) {
            lcDestination += "&nbsp;&nbsp;&nbsp;&nbsp;(" + loJourney.destination_latitude.toFixed(4) + ", " + loJourney.destination_longitude.toFixed(4) + ")</span>"
        }
        $("#txtDestination").html(lcDestination);

        // Vehicle
        $("#txtVehicleUnitID3").val(loJourney.vehicle_unit_id);
        $("#txtAvlSystem3").val(loJourney.avl_system);
        $("#txtVehicleColor3").val(loJourney.vehicle_color);
        $("#txtVehicleYear3").val(loJourney.vehicle_year);
        $("#txtVehicleMake3").val(loJourney.vehicle_make);
        $("#txtVehicleModel3").val(loJourney.vehicle_model);
        $("#txtVehicleLicensePlate3").val(loJourney.vehicle_license_plate);

        // Destination contact
        $("#txtDestinationContact3").val(loJourney.destination_contact);
        $("#txtDestinationPhone3").val(loJourney.destination_phone);

    }

    var populateEmployeeFields = function () {
        var loEmployee = JSON.parse(localStorage.Employee);
        var lcEmployeeName = loEmployee.first_name + " " + loEmployee.last_name;
        $("#txtEmployeeName3").val(lcEmployeeName);
        $("#txtCellNumber3").val(loEmployee.cell_number);
        $("#txtEmailAddress3").val(loEmployee.email_address);
    }

    var populateEmployeeContactFields = function () {
        $("#lstEmergencyContacts3").empty();
        $("#lstEmergencyContacts3").append("<li data-role='list-divider'>Emergency Contacts</li>");
        var lcolEmployeeContacts = JSON.parse(localStorage.EmployeeContacts);
        $.each(lcolEmployeeContacts, function (i, rec) {
               var lcItem = "<li class='ui-field-contain'>" +
                         "<h2>" + rec.contact_name + "</h2>" +
                         "<label>" + rec.phone_type_1 + ":" + rec.phone_number_1 + "</label>" +
                         "</li>"
            $("#lstEmergencyContacts3").append(lcItem);
        });
        $("#lstEmergencyContacts3").listview("refresh");
    }
    
    var populateLogFields = function (logRecs) {

        var lcolJourneyLogRecs = logRecs;

        //-- create journey log presentation items

        var lcolJourneyLogItems = [];
        var loJourneyLogItem = {};

        //Departure 
        loJourneyLogItem.Status = "Departure";
        loJourneyLogItem.Area = vdis.ActiveJourney.departure_area || "";
        loJourneyLogItem.Time = utcStringToDateTimeString(vdis.ActiveJourney.departure_datetime);
        if (vdis.ActiveJourney.departure_latitude && vdis.ActiveJourney.departure_longitude) {
            loJourneyLogItem.LatLon = vdis.ActiveJourney.departure_latitude.toFixed(4) + ", " + vdis.ActiveJourney.departure_longitude.toFixed(4);
        }
        else {
            loJourneyLogItem.LatLon = "";
        }
        lcolJourneyLogItems[0] = loJourneyLogItem;

        //Check-ins
        var ldPrevLogRecTime = new Date(vdis.ActiveJourney.departure_datetime);
        $.each(lcolJourneyLogRecs, function (i, loJourneyLogRec) {
            loJourneyLogItem = {};
            loJourneyLogItem.Status = statusIdToName(loJourneyLogRec.checkin_status);
            loJourneyLogItem.Area = loJourneyLogRec.checkin_area || "";
            //use actual time if entered, otherwise use tentative due time
            if (loJourneyLogRec.checkin_actual_time) {
                var ldCheckinActual = new Date(loJourneyLogRec.checkin_actual_time);
                loJourneyLogItem.Time = sameDayTime(ldCheckinActual, ldPrevLogRecTime);
                ldPrevLogRecTime = ldCheckinActual;
            }
            else {
                var ldCheckinDue = new Date(loJourneyLogRec.checkin_due_time);
                loJourneyLogItem.Time = "? " + sameDayTime(ldCheckinDue, ldPrevLogRecTime);
                ldPrevLogRecTime = ldCheckinDue;
            }
            if (loJourneyLogRec.latitude && loJourneyLogRec.longitude) {
                loJourneyLogItem.LatLon = loJourneyLogRec.latitude.toFixed(4) + ", " + loJourneyLogRec.longitude.toFixed(4);
            }
            else {
                loJourneyLogItem.LatLon = "";
            }
            lcolJourneyLogItems.push(loJourneyLogItem);
        });
        vdis.ActiveCheckin = lcolJourneyLogRecs[lcolJourneyLogRecs.length - 1];

        //Tentative Check-ins
        var ldTentativeCheckinTime = new Date(0);
        if (!vdis.ActiveJourney.actual_arrival_datetime)
        {
            var ldEta = new Date(vdis.ActiveJourney.eta)
            var liMinutesToDestination = ldPrevLogRecTime.diffMinutes(ldEta);
            var liTentativeCheckinCount = parseInt(liMinutesToDestination / vdis.ActiveJourney.checkin_interval);
            if (liTentativeCheckinCount > 250) {
                lcolJourneyLogItems.push({ Area: "TOO MANY POINTS", Status: "", Time: "", LatLon: "" });
            }
            else {
                for (i = 1; i <= liTentativeCheckinCount; i++) {
                    ldTentativeCheckinTime = ldPrevLogRecTime.addMinutes(vdis.ActiveJourney.checkin_interval);
                    lcolJourneyLogItems.push({
                        Time: "? " + sameDayTime(ldTentativeCheckinTime, ldPrevLogRecTime),
                        Status: "",
                        Area: "",
                        LatLon: ""
                    });
                    ldPrevLogRecTime = ldTentativeCheckinTime;
                }
            }
        }

        //Destination
        loJourneyLogItem = {};
        loJourneyLogItem.Status = "Destination";
        loJourneyLogItem.Area = vdis.ActiveJourney.destination_area || "";
        if (vdis.ActiveJourney.actual_arrival_datetime) {
            var ldActualArrival = new Date(vdis.ActiveJourney.actual_arrival_datetime)
            loJourneyLogItem.Time = sameDayTime(ldActualArrival, ldPrevLogRecTime);
        }
        else {
            var ldEta = new Date(vdis.ActiveJourney.eta)
            loJourneyLogItem.Time = "? " + sameDayTime(ldEta, ldPrevLogRecTime);
        }
        if (vdis.ActiveJourney.destination_latitude && vdis.ActiveJourney.destination_longitude) {
            loJourneyLogItem.LatLon = vdis.ActiveJourney.destination_latitude.toFixed(4) + ", " + vdis.ActiveJourney.destination_longitude.toFixed(4);
        }
        else {
            loJourneyLogItem.LatLon = "";
        }
        lcolJourneyLogItems.push(loJourneyLogItem);

        // create list UI
        $("#lstJourneyLog3").empty();

       
        $.each(lcolJourneyLogItems, function (i, item) {
               var lcItem = "<li>" +
               "<h2>" + (item.Status ? item.Status : "&nbsp;&nbsp;&nbsp;&nbsp;") + "</h2>" +
               "<p style='white-space: pre-wrap'>" + item.Area + (item.LatLon ? ("&nbsp;&nbsp;&nbsp;&nbsp;(" + item.LatLon + ")") : "") + "</p>" +
               "<p class='ui-li-aside' style='top:1.7em'><strong>" + item.Time + "</strong></p>" +
               "</li>"
               $("#lstJourneyLog3").append(lcItem);
               });
        $("#lstJourneyLog3").listview("refresh");


        //-- Set calculated fields

        setCheckinDisplay();
    }

    function setCheckinDisplay() {

        var loJourney = vdis.ActiveJourney;
        $("#txtCheckinInterval").val(Math.floor(loJourney.checkin_interval / 60.0) + " hr  " + loJourney.checkin_interval % 60 + " min");
        if (vdis.ActiveCheckin.checkin_status == 2)
        {
            // on standby
            $("#txtNextCheckin").val("Standby");
        }
        else
        {
            var ldNow = new Date();
            var ldCheckinDue = new Date(vdis.ActiveCheckin.checkin_due_time);
            var liNextCheckinMinutes = ldNow.diffMinutes(ldCheckinDue);
            $("#txtNextCheckin").val(sameDayTime(ldCheckinDue, ldNow) + "  " + liNextCheckinMinutes + " min");
        }
    }

    // get active journey ID
    var getActiveJourneyID = function () {
        var lcApiUri = getApiUri("api/journeys/active/journeyid");
        $.getJSON(lcApiUri)
            .done(function (data) {
                if ((data || 0) > 0) {
                    vdis.ActiveJourneyID = data;
                    getJourneyRecord();
                }
                else {
                    $.mobile.loading("hide");
                    vdis.ActiveJourneyID = 0; //indicates that there is no active journey
                    enableDisableButtons(true);
                    vdis.newJourneyPage.data = {};
                    $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html", { changeHash: false });
                }
            }).fail(function (xhr, status, error) {
                $.mobile.loading("hide");
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Journey ID");
            });
    }

    // get journey record
    var getJourneyRecord = function () {
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID);
        $.getJSON(lcApiUri)
            .done(function (data) {
                vdis.ActiveJourney = data;
                localStorage.ActiveJourney = JSON.stringify(vdis.ActiveJourney);
                populateJourneyFields();
                enableDisableButtons(true);
                miAsyncOperationCount = 3;
                getEmployeeRecord();
                getEmployeeContactRecords();
                getJourneyLogItems();
            }).fail(function (xhr, status, error) {
                $.mobile.loading("hide");
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Journey Record");
            });
    }

    // get Me data
    var getEmployeeRecord = function () {
        // user can only access own employee record
        var lcApiUri = getApiUri("api/employees");
        $.getJSON(lcApiUri)
            .done(function (data) {
                localStorage.Employee = JSON.stringify(data);
                populateEmployeeFields();
                miAsyncOperationCount -= 1;
                if (miAsyncOperationCount == 0) {
                    $.mobile.loading("hide");
                }
            }).fail(function (xhr, status, error) {
                $.mobile.loading("hide");
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee Record");
            });
    }

    // get Employee Contacts data
    var getEmployeeContactRecords = function () {
        // user can only access own employee record
        var lcApiUri = getApiUri("api/employees/contacts");
        $.getJSON(lcApiUri)
            .done(function (data) {
                localStorage.EmployeeContacts = JSON.stringify(data);
                populateEmployeeContactFields();
                miAsyncOperationCount -= 1;
                if (miAsyncOperationCount == 0) {
                    $.mobile.loading("hide");
                }
            }).fail(function (xhr, status, error) {
                $.mobile.loading("hide");
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee Contacts");
            });
    }

    // get Journey Log data
    var getJourneyLogItems = function () {
        var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/log");
        $.getJSON(lcApiUri)
            .done(function (data) {
                populateLogFields(data);
                miAsyncOperationCount -= 1;
                if (miAsyncOperationCount == 0) {
                    $.mobile.loading("hide");
                }
            }).fail(function (xhr, status, error) {
                $.mobile.loading("hide");
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Journey Log");
            });
    }


    //--- main ---


    // disable buttons until active journey is determined
    enableDisableButtons(false);

    $.mobile.loading("show");

    getActiveJourneyID();


    //--- event handlers and actions ---


    // When a tab button is pressed, hide panels and reveal the select panel
    $(".journeyPageTabs a").click(function () {
        $("#journeyPage > .ui-content > div").addClass("hidden");
        var lcTabName = this.id.substring(3);  // button name minus the prefix
        var lcTabID = "journey" + lcTabName + "Tab";
        $("#" + lcTabID).removeClass("hidden");
    });

    var checkinImmediately = function () {

        this.noGeolocationResponse = function () {
            $.mobile.loading("hide");
            $("#btnImmediateCheckin").removeClass("ui-btn-active");
            messageBox.show("Unable to get current position. Immediate checkin is not possible. Use the Check In (or standby/revise ETA) button on the journey page.", "Get Current Location");
            enableDisableButtons(true);
        }

        var loImmediateCheckinJourneyLog = {};

        if (!navigator.geolocation) {
            messageBox.show("Location services are not available in your browser. Immediate checkin is not possible. Use the Check In (or standby/revise ETA) button.", "Current Location");
            return;
        }

        $.mobile.loading("show");
        enableDisableButtons(false);

        var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);

        // get current location
        navigator.geolocation.getCurrentPosition(function (position) {
            clearTimeout(loWaitForLocationServices);
            loImmediateCheckinJourneyLog.latitude = position.coords.latitude;
            loImmediateCheckinJourneyLog.longitude = position.coords.longitude;

            //reverse geocode location
            var loLatLon = { lat: position.coords.latitude, lon: position.coords.longitude };
            var loGeocoder = L.mapbox.geocoder('mapbox.places');
            loGeocoder.reverseQuery(loLatLon, function (err, data) {
                $.mobile.loading("hide");
                if (data) {
                    loImmediateCheckinJourneyLog.checkin_area = getFormattedAddress(data);
                    confirmCheckin();
                }
            });

        }, function (error) {
            clearTimeout(loWaitForLocationServices);
            $.mobile.loading("hide");
            $("#btnImmediateCheckin").removeClass("ui-btn-active");
            var lcMessage = getCurrentPositionErrorMessage(error);
            messageBox.show(lcMessage, "Get Current Location");
            enableDisableButtons(true);
        }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });

        this.confirmCheckin = function () {
            $.mobile.loading("hide");
            if (vdis.ActiveCheckin.checkin_status == ResumeStatus) {
                messageBox.show("You are currently on standby, would you like to resume your journey?", "Confirm",
                    function (okPressed) {
                        if (okPressed) {
                            loImmediateCheckinJourneyLog.checkin_status = ResumeStatus;
                            checkin();
                        }
                        else {
                            enableDisableButtons(true);
                        }
                    }, true);
            }
            else {
                messageBox.show("Check-in now using current location?", "Check-in",
                    function (okPressed) {
                        if (okPressed) {
                            loImmediateCheckinJourneyLog.checkin_status = CheckinStatus;
                            checkin();
                        }
                        else {
                            enableDisableButtons(true);
                        }
                    }, true);
            }
        }

        this.checkin = function () {
            var loJourney = vdis.ActiveJourney;
            var loJourneyDate = new Date(loJourney.departure_datetime);
            var todayDate = new Date();

            var timesDifference = Math.abs(loJourneyDate.getTime() - todayDate.getTime());
            var daysDifference = Math.ceil(timesDifference / (1000 * 3600 * 24));
            var hoursDifference = (loJourneyDate - todayDate) / 3600000;

                $.mobile.loading("show");
                var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/checkin");
                lcApiUri += "&revisedEta="
                $.ajax({
                       type: "POST",
                       url: lcApiUri,
                       data: loImmediateCheckinJourneyLog
                       }).always(function () {
                                 $.mobile.loading("hide");
                                 $("#btnImmediateCheckin").removeClass("ui-btn-active");
                                 enableDisableButtons(true);
                                 }).done(function () {
                                         getJourneyRecord();
                                         messageBox.show("Successfully checked in.", "Checkin");
                                         }).fail(function (xhr, status, error) {
                                                 messageBox.show(getAjaxErrorMessage(xhr, status, error), "Checkin");
                                                 });
   
            }
    }

    var closeJourneyImmediately = function () {

        var loImmediateCloseData = {
            destination_latitude: null,
            destination_longitude: null
        };


        this.noGeolocationResponse = function () {
            $.mobile.loading("hide");
            $("#btnImmediateArrived").removeClass("ui-btn-active");
            messageBox.show("Unable to get current position. Closing to booked destination without coordinates.", "Get Current Location",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            else {
                            enableDisableButtons(true);
                            };
                            },true);
        }

        if (!navigator.geolocation) {
            messageBox.show("Unable to get current position. Closing to booked destination without coordinates.", "Get Current Location",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            else {
                            enableDisableButtons(true);
                            };
                            },true);
            return;
        }

        $.mobile.loading("show");
        enableDisableButtons(false);

        var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);

        // get current location
        navigator.geolocation.getCurrentPosition(function (position) {
            clearTimeout(loWaitForLocationServices);
            loImmediateCloseData.destination_latitude = position.coords.latitude;
            loImmediateCloseData.destination_longitude = position.coords.longitude;
            confirmClose();
        }, function (error) {
            clearTimeout(loWaitForLocationServices);
            $.mobile.loading("hide");
            $("#btnImmediateArrived").removeClass("ui-btn-active");
            var lcMessage = getCurrentPositionErrorMessage(error) + " Closing to booked destination without coordinates.";
            messageBox.show(lcMessage, "Get Current Location",
                            function (okPressed) {
                            if(okPressed){
                            closeJourney();
                            }
                            else {
                            enableDisableButtons(true);
                            };
                            },true);
        }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });

        this.confirmClose = function () {
            $.mobile.loading("hide");
            messageBox.show("Close journey using current location?", "Confirm",
                function (okPressed) {
                    if (okPressed) {
                        closeJourney();
                    } else {
                        enableDisableButtons(true);
                    };
                }, true);
        }

        this.closeJourney = function () {

            $.mobile.loading("show");
            var lcApiUri = getApiUri("api/journeys/" + vdis.ActiveJourneyID + "/close");
            $.ajax({
                type: "POST",
                url: lcApiUri,
                data: loImmediateCloseData
            }).always(function () {
                $.mobile.loading("hide");
                $("#btnImmediateArrived").removeClass("ui-btn-active");
                enableDisableButtons(true);
            }).done(function () {
                var ldNow = new Date();
                // save to previous journeys list
                vdis.ActiveJourney.actual_arrival_datetime = dateToUtcString(ldNow);
                lcolPreviousJourneys = [];
                if (localStorage.PreviousJourneys) {
                    lcolPreviousJourneys = JSON.parse(localStorage.PreviousJourneys);
                }
                vdis.ActiveJourney.IsFavorite = false;
                lcolPreviousJourneys.insert(0, vdis.ActiveJourney);
                if (lcolPreviousJourneys.length > 20) {
                    for (i = lcolPreviousJourneys.length - 1; i >= 20; i--) {
                        var loPrevJourney = lcolPreviousJourneys[i];
                        if (!loPrevJourney.IsFavorite) {
                            lcolPreviousJourneys.removeAt(i)
                        }
                    }
                }
                localStorage.PreviousJourneys = JSON.stringify(lcolPreviousJourneys);
                // reset active journey data
                vdis.ActiveJourneyID = 0;
                vdis.ActiveJourney = null;
                vdis.ActiveCheckin = null;
                // finish up
                messageBox.show("Journey successfully closed.", "Close Journey",
                    function (okPressed) {
                                  clearInterval(idleInterval);
                                SetButtonVisibility();
                                $.mobile.back();
                    }, false);
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Close Journey");
            });
        }
    }
    var idleTime = 0;
    var idleInterval;
    $(document).ready(function () {
                      //Increment the idle time counter every minute.
                      idleInterval = setInterval(timerIncrement, 1000); // 1 Sec
                      
                      });
    
    function timerIncrement() {
        idleTime = idleTime + 1;
        if (idleTime > 60) { // 60 Sec
            
            getActiveJourneyID();
            idleTime = 0;
            
        }
    }
    $("#btnCheckin").click(function () {

        $.mobile.pageContainer.pagecontainer("change", "CheckinPage.html");

    });

    $("#btnArrived").click(function () {

        closeJourneyImmediately();

    });


    // Toolbar --

    $("#btnImmediateCheckin").click(function () {

        checkinImmediately();

    });

    $("#btnRefresh").click(function () {
        $.mobile.loading("show");
        getActiveJourneyID();

    });

    $("#btnImmediateArrived").click(function () {

        closeJourneyImmediately();

    });
    $("#btnPageBack").click(function () {
                            
                            clearInterval(idleInterval);
                            SetButtonVisibility();
                            //$.mobile.back();
                             $.mobile.pageContainer.pagecontainer("change", "index.html", { changeHash: false });
                            
                            });

/*-- Inorder to avoid the popup box merging with header of footer below line is included-- */
    
    $("#journeyPage").on("scrollstart",function(){
                   $("#messageboxPopup").popup("close");
                   enableDisableButtons(true);
                   });
    
    

}




