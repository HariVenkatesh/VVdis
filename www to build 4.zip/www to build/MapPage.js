﻿vdis.mapPage.loadPage = function () {

    var divMapContainer = document.getElementById('mapContainer');
    var moMap;
    var moCurrentPositionMarker, moDestinationMarker;
    var moCurrentLocation;

    function resizeMapContainer() {
        divMapContainer.style.width = $(window).width().toString() + "px";
        divMapContainer.style.height = ($(window).height() - $("#header").height() - 2).toString() + "px";
    }

    function resizeMap() {
        resizeMapContainer();
    }

    function setupMap() {

        resizeMapContainer();

        window.onresize = function (e) {
            resizeMap();
        }

        moMap = L.mapbox.map(divMapContainer, 'mapbox.streets');

        L.control.layers({
            "Road": moMap.tileLayer,
            "Satellite": L.mapbox.tileLayer("mapbox.satellite"),
            "Hybrid": L.mapbox.tileLayer("mapbox.streets-satellite")
        }, null).addTo(moMap);

    }

    var zoomToCurrentLocation = function () {

        var noGeolocationResponse = function () {
            $.mobile.loading("hide");
            messageBox.show("Unable to get current position - no repsonse from location services.", "Get Current Location",
                function (okPressed) {
                    $.mobile.back();
                }, false);
        }

        var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);

        // get current location
        //if (!moCurrentLocation) {
        if (!moCurrentPositionMarker) {
            $.mobile.loading("show");
            navigator.geolocation.getCurrentPosition(function (position) {
                clearTimeout(loWaitForLocationServices);
                $.mobile.loading("hide");
                moCurrentLocation = { lat: position.coords.latitude, lng: position.coords.longitude }
                if (!moCurrentPositionMarker) {
                    var loIcon = new L.Icon({ iconUrl: "Content/images/vdis-icons/current-location.png", iconSize: [32, 32], iconAnchor: [16, 16] });
                    moCurrentPositionMarker = new L.Marker(moCurrentLocation, { icon: loIcon }).addTo(moMap);
                }
                moMap.setView(moCurrentLocation, 10);
            }, function (error) {
                clearTimeout(loWaitForLocationServices);
                $.mobile.loading("hide");
                var lcMessage = getCurrentPositionErrorMessage(error);
                messageBox.show(lcMessage, "Get Current Location");
            }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });
        }
        else {
            clearTimeout(loWaitForLocationServices);
            moMap.setView(moCurrentLocation, 10);
        }

    }

    var zoomToDestination = function () {

        var loJourney = vdis.ActiveJourney;
        if (!loJourney) {
            loJourney = JSON.parse(localStorage.ActiveJourney);
            if (!loJourney) {
                messageBox.show("The journey destination is unknown.", "Unknown Active Journey");
                return;
            }
        }

        if (loJourney.destination_latitude && loJourney.destination_longitude) {
            var lnLatitude = loJourney.destination_latitude;
            var lnLongitude = loJourney.destination_longitude;
            if (!moDestinationMarker) {
                var loIcon = new L.Icon({ iconUrl: "Content/images/vdis-icons/location.png", iconSize: [34, 45], iconAnchor: [17, 45] });
                moDestinationMarker = new L.Marker([lnLatitude, lnLongitude], { icon: loIcon }).addTo(moMap);
            }
            moMap.setView([lnLatitude, lnLongitude], 10);
        }
        else {
            messageBox.show("The journey destination is unknown.", "Unknown Latitude/Longitude");
            return;
        }

    }

    var zoomRelative = function () {

        var loJourney = vdis.ActiveJourney;
        if (!loJourney) {
            loJourney = JSON.parse(localStorage.ActiveJourney);
            if (!loJourney) {
                messageBox.show("The journey destination is unknown.", "Unknown Active Journey");
                return;
            }
        }

        if (!moCurrentLocation) {
            messageBox.show("Current location is unknown.", "Unknown Location");
            return;
        }

        if (!moCurrentPositionMarker) {
            var loIcon = new L.Icon({ iconUrl: "Content/images/vdis-icons/current-location.png", iconSize: [32, 32], iconAnchor: [16, 16] });
            moCurrentPositionMarker = new L.Marker(moCurrentLocation, { icon: loIcon }).addTo(moMap);
        }

        if (loJourney.destination_latitude && loJourney.destination_longitude) {
            var lnLatitude = loJourney.destination_latitude;
            var lnLongitude = loJourney.destination_longitude;
            if (!moDestinationMarker) {
                var loIcon = new L.Icon({ iconUrl: "Content/images/vdis-icons/location.png", iconSize: [34, 45], iconAnchor: [17, 45] });
                moDestinationMarker = new L.Marker([lnLatitude, lnLongitude], { icon: loIcon }).addTo(moMap);
            }
            moMap.fitBounds([[moCurrentLocation.lat, moCurrentLocation.lng], [lnLatitude, lnLongitude]]);
        }
        else {
            messageBox.show("The journey destination is unknown.", "Unknown Latitude/Longitude");
            return;
        }

    }


    //--- main ---

    setupMap();
    zoomToCurrentLocation();


    //--- event handlers ---


    $("#btnZoomToCurrentLocation").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            if(moDestinationMarker){
                moMap.removeLayer(moDestinationMarker);
                moDestinationMarker = null;
            }
            zoomToCurrentLocation();
        }

    });

    $("#btnZoomToDestination").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            if(moCurrentPositionMarker){
                moMap.removeLayer(moCurrentPositionMarker);
                moCurrentPositionMarker = null;
            }
            zoomToDestination();
        }

    });

    $("#btnZoomRelative").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            zoomRelative();
        }

    });

}