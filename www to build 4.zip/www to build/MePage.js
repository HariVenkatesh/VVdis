﻿vdis.mePage.loadPage = function () {

    var populateEmployeeFields = function () {
        var loEmployee = JSON.parse(localStorage.Employee);
        var lcEmployeeName = loEmployee.first_name + " " + loEmployee.last_name;
        $("#lblEmployeeName2").html(lcEmployeeName);
        $("#txtCellNumber2").val(loEmployee.cell_number);
        $("#txtEmailAddress2").val(loEmployee.email_address);
    }

    $.mobile.loading("show");
    // user can only access own employee record
    var lcApiUri = getApiUri("api/employees");
    $.getJSON(lcApiUri)
        .done(function (data) {
            localStorage.Employee = JSON.stringify(data);
            populateEmployeeFields();
        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee");
        }).always(function () {
            $.mobile.loading("hide");
        });

    $("#btnSaveMe").click(function () {

        // Validate required fields
        if ($("#txtCellNumber2").val().trim() == '') {
            messageBox.show("Cell Number must be entered.", "Required");
            return;
        }
        if ($("#txtEmailAddress2").val().trim() == '') {
            messageBox.show("Email Address must be entered.", "Required");
            return;
        }

        // Commit Controls
        var loEmployee = JSON.parse(localStorage.Employee);
        if (loEmployee.cell_number != $("#txtCellNumber2").val() ||
                loEmployee.email_address != $("#txtEmailAddress2").val()) {
            loEmployee.cell_number = $("#txtCellNumber2").val();
            loEmployee.email_address = $("#txtEmailAddress2").val();

            // Save
            $.mobile.loading("show");
            var lcApiUri = getApiUri("api/employees");
            $.ajax({
                type: "PUT",
                url: lcApiUri,
                data: loEmployee
            }).always(function () {
                $.mobile.loading("hide");
            }).done(function () {
                localStorage.Employee = JSON.stringify(loEmployee);
                $.mobile.back();
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Save Employee");
            });
        }
        else {
              
              $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
//            $.mobile.back();
        }

    });
}




