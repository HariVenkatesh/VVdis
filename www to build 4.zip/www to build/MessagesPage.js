﻿vdis.messagesPage.loadPage = function () {

    var miLastMessageRecID = 0;
    var mcolMessages = [];

    var getThumbImageName = function (direction) {
        if (direction == "OUT") {
            return "msg.received.png";
        }
        else {
            return "msg.sent.png";
        }
    }


    var populateMessagesList = function (filter) {
        $("#lstMessages").empty();
        $.each(mcolMessages, function (i, rec) {
            if (filter == "Received" && rec.direction == "IN") {
                // received messages have a direction of OUT from the server's perspective
                return true;
            }
            if (filter == "Sent" && rec.direction == "OUT") {
                // sent messages have a direction of IN from the server's perspective
                return true;
            }
            var lcThumbImageName = getThumbImageName(rec.direction);
            var lcItem = "<li style='padding-left:40px'>" +
                            "<img src='Content/images/vdis-icons/" + lcThumbImageName + "' >" +
                            "<h2 style='white-space:pre-wrap'>" + utcStringToDateTimeString(rec.action_datetime) + "<br />Journye ID: " + padNumericID(rec.journey_id, 8) + "</h2>" +
                            "<label style='white-space:pre-wrap'>" + rec.message_text + "</label>" +
                            "</li>"
            $("#lstMessages").append(lcItem);
            
        });
        $("#lstMessages").listview("refresh");
    }

    var getUnreadMessages = function () {
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/notifications/unread-messages/" + miLastMessageRecID);
        $.getJSON(lcApiUri)
            .done(function (data) {

                miLastMessageRecID = 0
                var lbDup = false;
                $.each(data, function (i, newRec) {
                    //add to collection if not already there
                    lbDup = false;
                    $.each(mcolMessages, function (j, existingRec) {
                        if (existingRec.rec_id == newRec.rec_id) {
                            lbDup = true;
                            return false;
                        }
                    });
                    if (!lbDup) {
                        mcolMessages.splice(0, 0, newRec);
                    }
                    miLastMessageRecID = newRec.rec_id;
                });
                //remove messages in excess of 50
                if (mcolMessages.length > 50) {
                    mcolMessages.splice(50, mcolMessages.length - 50);
                }
                localStorage.Messages = JSON.stringify(mcolMessages);
                
                //recreate the filtered views
                populateMessagesList("All");

                //send last rec ID back to server so that these messages can be marked as acknowledged (read)
                acknowledgeReadMessages(miLastMessageRecID);

            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Unread Messages");
            }).always(function () {
                $.mobile.loading("hide");
                $("#btnRefresh").removeClass("ui-btn-active");
            });
    }

    var acknowledgeReadMessages = function (lastMessageRecID) {
        var lcApiUri = getApiUri("api/notifications/acknowledge-read-messages/" + lastMessageRecID);
        $.ajax({
            type: "PUT",
            url: lcApiUri
        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Acknowledge Read Messages");
        });

    }


    //--- main ---


    if (localStorage.Messages) {
        mcolMessages = JSON.parse(localStorage.Messages);
        $.each(mcolMessages, function (i, rec) {
            //received messages have a direction of OUT from the server's perspective
           if (rec.direction == "OUT" && rec.rec_id > miLastMessageRecID) {
                miLastMessageRecID = rec.rec_id;
            }
        });
        populateMessagesList("All");
    }
    $("#btnReceived").removeClass("ui-btn-active");
    $("#btnSent").removeClass("ui-btn-active");
    $("#btnAll").addClass("ui-btn-active");
    getUnreadMessages(miLastMessageRecID);



    //--- event handlers and actions ---


    // When a tab button is pressed, change filtered list
    $(".messagesPageTabs a").click(function () {
        var lcTabName = this.id.substring(3);  // button name minus the prefix
        populateMessagesList(lcTabName);
    });

    $("#btnNewMessage").click(function () {
        $.mobile.pageContainer.pagecontainer("change", "NewMessagePage.html");
    });

    $("#btnRefresh").click(function () {
        getUnreadMessages(miLastMessageRecID);
    });
}




