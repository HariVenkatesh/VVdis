﻿vdis.myEmergencyContactsPage.loadPage = function () {

    var populateEmployeeContactFields = function () {
        $("#lstEmergencyContacts2").empty();
        vdis.myEmergencyContactsPage.employeeContacts = JSON.parse(localStorage.EmployeeContacts);
        $.each(vdis.myEmergencyContactsPage.employeeContacts, function (i, rec) {
            var lcItem = "<li id='item" + i + "'>" +
                         "<a class='ui-btn ui-btn-icon-right ui-icon-edit' href='#'>" +
                         "<h2>" + rec.contact_name + "</h2>" +
                         "<label>" + rec.phone_type_1 + ":" + rec.phone_number_1 + "</label>" +
                         "</a>" +
                         "</li>"
            $("#lstEmergencyContacts2").append(lcItem);
        });
        $("#lstEmergencyContacts2").listview("refresh");
    }

    $.mobile.loading("show");
    // user can only access own employee contact records
    var lcApiUri = getApiUri("api/employees/contacts");
    $.getJSON(lcApiUri)
        .done(function (data) {
            localStorage.EmployeeContacts = JSON.stringify(data);
            populateEmployeeContactFields();
        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee Contacts");
        }).always(function () {
            $.mobile.loading("hide");
        });

    $("#lstEmergencyContacts2").on("click", "li", function () {

        vdis.editEmergencyContactPage.editMode = "Edit";
        var lcSelectedItemID = this.id;
        var liItemIndex = parseInt(lcSelectedItemID.substring(4));
        var loEmployeeContact = vdis.myEmergencyContactsPage.employeeContacts[liItemIndex];
        vdis.editEmergencyContactPage.data = loEmployeeContact;
        $(":mobile-pagecontainer").pagecontainer("change", "EditEmergencyContactPage.html");

    });

    $("#btnAdd").click(function () {

        var loAccount = JSON.parse(localStorage.Account);
        vdis.editEmergencyContactPage.editMode = "New";
        vdis.editEmergencyContactPage.data = {
            employee_id: loAccount.employee_id,
            contact_name: "",
            phone_type_1: "Cell",
            phone_number_1: ""
        };
        $(":mobile-pagecontainer").pagecontainer("change", "EditEmergencyContactPage.html");

    });
}


