vdis.myProfilePage.loadPage = function () {

    var populateEmployeeFields = function () {
        var loEmployee = JSON.parse(localStorage.Employee);
        var lcEmployeeName = loEmployee.first_name + " " + loEmployee.last_name;
        $("#lblEmployeeName").html(lcEmployeeName);
        $("#txtCellNumber").val(loEmployee.cell_number);
        $("#txtEmailAddress").val(loEmployee.email_address);
    }

    var populateVehicleFields = function () {
        var loVehicle = JSON.parse(localStorage.Vehicle);
        $("#txtUnitID").val(loVehicle.vehicle_unit_id);
        $("#txtAvlSystem").val(loVehicle.avl_system);
        $("#txtVehicleColor").val(loVehicle.vehicle_color);
        $("#txtVehicleYear").val((loVehicle.vehicle_year || 0 > 1900) ? loVehicle.vehicle_year.toString() : "");
        $("#txtVehicleMake").val(loVehicle.vehicle_make);
        $("#txtVehicleModel").val(loVehicle.vehicle_model);
        $("#txtVehicleLicensePlate").val(loVehicle.vehicle_license_plate);
    }

    var blankVehicleFields = function () {
        $(".vehicle-field").val("");
    }

    var populateEmployeeContactFields = function () {

        $("#lstEmergencyContacts").empty();
        var lcolEmployeeContacts = JSON.parse(localStorage.EmployeeContacts);
        $.each(lcolEmployeeContacts, function (i, rec) {
            var lcItem = "<li class='ui-field-contain'>" +
                         "<h2>" + rec.contact_name + "</h2>" +
                         "<label>" + rec.phone_type_1 + ": " + rec.phone_number_1 + "</label>" +
                         "</li>"
            $("#lstEmergencyContacts").append(lcItem);
        });
        $("#lstEmergencyContacts").listview("refresh");
    }

    var populateAccountFields = function () {
        var loAccount = JSON.parse(localStorage.Account);
        $("#txtCompanyName").val(loAccount.company_name);
        $("#txtAccountType").val(loAccount.account_type);
    }

  

    // grab the AppVersion.json file using ajax and compare with AppVersion variable to see if 
    // the page needs to be reloaded (we are viewing a cached version)
    var checkAppVersion = function () {
        var noCache = new Date().getTime();
        $.getJSON("Scripts/appConfig.json", { "noCache": noCache })
            .done(function (data) {
                if (data.appVersion != AppVersion) {
                    //reload the page
                    location.reload(true);
                }
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get App Version");
            });
    }


  

    // get active journey ID
    var getActiveJourneyID = function () {
        var lcApiUri = getApiUri("api/journeys/active/journeyid");
        $.getJSON(lcApiUri)
            .done(function (data) {
                if (data) {
                    vdis.ActiveJourneyID = data;                  
                }
                else {
                    vdis.ActiveJourneyID = 0; //indicates that there is no active journey                   
                }
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Journey ID");
            });
    }

    // get Me data
    var getEmployee = function () {
        if (localStorage.Employee) {
            populateEmployeeFields();
        }
        else {
            // user can only access own employee record
            var lcApiUri = getApiUri("api/employees");
            $.getJSON(lcApiUri)
                .done(function (data) {
                    localStorage.Employee = JSON.stringify(data);
                    populateEmployeeFields();
                }).fail(function (xhr, status, error) {
                    messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee");
                });
        }
    }

    // get vehicle
    var getVehicle = function(){
        // get vehicle
        if (localStorage.Vehicle) {
            populateVehicleFields();
        }
        else {
            blankVehicleFields();  // if reactivating need to clear these out
        }
    }

    // get employee contacts
    var getEmployeeContacts = function () {
        if (localStorage.EmployeeContacts) {
            populateEmployeeContactFields();
        }
        else {
            // user can only access own employee contact records
            var lcApiUri = getApiUri("api/employees/contacts");
            $.getJSON(lcApiUri)
                .done(function (data) {
                    localStorage.EmployeeContacts = JSON.stringify(data);
                    populateEmployeeContactFields();
                }).fail(function (xhr, status, error) {
                    messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Employee Contacts");
                });
        }
    }

    // get account
    var getAccount = function () {
        if (localStorage.Account) {
            populateAccountFields();
        }
    }



    //--- main ---

    checkAppVersion();
    getActiveJourneyID();
    getEmployee();
    getVehicle();
    getEmployeeContacts();
    getAccount();

    // about
    $("#txtAppVersion").val(AppVersion);


    //--- event handlers and actions ---
      

    $("#btnEditMe").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            $.mobile.pageContainer.pagecontainer("change", "MePage.html");
        }

    });

    $("#btnEditVehicle").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            $.mobile.pageContainer.pagecontainer("change", "MyVehiclePage.html");
        }

    });

    $("#btnEditEmergencyContacts").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            $.mobile.pageContainer.pagecontainer("change", "MyEmergencyContactsPage.html");
        }

    });

    $("#btnAccount").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            $.mobile.pageContainer.pagecontainer("change", "AccountPage.html");
        }

    });

    
    $("#btnAbout").click(function (e) {

        if (e.handled !== true) {
            e.handled = true;
            $.mobile.pageContainer.pagecontainer("change", "AboutPage.html");
        }

    });
   
}


