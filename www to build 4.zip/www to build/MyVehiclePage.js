﻿vdis.myVehiclePage.loadPage = function () {

    var moVehicle = {};

    var populateVehicleFields = function () {
        $("#txtUnitID2").val(moVehicle.vehicle_unit_id);
        $("#txtAvlSystem2").val(moVehicle.avl_system);
        $("#txtVehicleColor2").val(moVehicle.vehicle_color);
        $("#txtVehicleYear2").val((moVehicle.vehicle_year || 0 > 1900) ? moVehicle.vehicle_year.toString() : "");
        $("#txtVehicleMake2").val(moVehicle.vehicle_make);
        $("#txtVehicleModel2").val(moVehicle.vehicle_model);
        $("#txtVehicleLicensePlate2").val(moVehicle.vehicle_license_plate);
    }


    //--- Main ---


    if (localStorage.Vehicle) {
        moVehicle = JSON.parse(localStorage.Vehicle);
        populateVehicleFields();
    }


    //--- Event handlers ---


    $("#btnDownload").click(function () {

        // Validate required fields
        if ($("#txtUnitID2").val().trim() == '') {
            messageBox.show("Unit ID must be entered in order to download details.", "Required");
            return;
        }

        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/vehicles/" + $("#txtUnitID2").val().trim());
        $.getJSON(lcApiUri)
            .done(function (data) {
                if (data) {
                    moVehicle = data;
                    populateVehicleFields();
                }
                else {
                    messageBox.show("Vehicle record not found on server.", "Download");
                }
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Download Vehicle");
            }).always(function () {
                $.mobile.loading("hide");
            });
    });

    $("#btnSaveVehicle").click(function () {

        // Validate required fields
        if ($("#txtUnitID2").val().trim() == '') {
            messageBox.show("Unit ID must be entered.", "Required");
            return;
        }
        var liYear = parseInt($("#txtVehicleYear2").val())
        if (isNaN(liYear)) {
            messageBox.show("Vehicle Year must be entered.", "Required");
            return;
        }
        var ldToday = new Date();
        if (liYear < 1900 || liYear > ldToday.getFullYear() + 2) {
            messageBox.show("Vehicle Year entered is not valid.", "Invalid");
            return;
        }

        moVehicle.vehicle_unit_id = $("#txtUnitID2").val();
        moVehicle.vehicle_color = $("#txtVehicleColor2").val();
        moVehicle.vehicle_year = liYear;
        moVehicle.vehicle_make = $("#txtVehicleMake2").val();
        moVehicle.vehicle_model = $("#txtVehicleModel2").val();
        moVehicle.vehicle_license_plate = $("#txtVehicleLicensePlate2").val();
        localStorage.Vehicle = JSON.stringify(moVehicle);
//        $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
        $.mobile.changePage("NewJourneyPage.html", {
                                                   transition: "fade",
                                                   changeHash: false,
                                                   reverse: false
                                                   });
        //$.mobile.back();
    });
}

