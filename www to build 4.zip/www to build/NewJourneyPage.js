vdis.newJourneyPage.loadPage = function () {

    $("#riskAssessmentScore").val(riskScore);
    
    var moJourney = vdis.newJourneyPage.data;
    var moConfig = {};

    var enableDisableButtons = function (enable) {
        if (enable) {
            $(".ui-btn").removeClass("ui-disabled");
        }
        else {
            $(".ui-btn").addClass("ui-disabled");
        }
    }

    var updateEta = function () {
        var liHours = 0
        var liMinutes = 0
        if ($("#txtDurationHours2").val()) {
            var liHours = parseInt($("#txtDurationHours2").val());
        }
        if ($("#txtDurationMinutes2").val()) {
            var liMinutes = parseInt($("#txtDurationMinutes2").val());
        }
        var liMinutesToArrival = liHours * 60 + liMinutes;
        var ldNow = new Date();
        var ldEta = ldNow.addMinutes(liMinutesToArrival);
        $("#txtEta").val(dateToDateTimeString(ldEta));
    }

    var checkJraThreshold = function () {
        var liRiskScore = $("#riskAssessmentScore").val();
        if (moConfig.JraSuspendedAboveBelow.toLowerCase() == "above") {
            if (liRiskScore > moConfig.JraThreshold) {
                messageBox.show("Risk score is beyond threshold. Please obtain manager approval prior to starting your trip.", "Approval Required");
                return;
            }
        }
        else {
            if (liRiskScore < moConfig.JraThreshold) {
                messageBox.show("Risk score is beyond threshold. Please obtain manager approval prior to starting your trip.", "Approval Required");
                return;
            }
        }
    }

    var setCheckinInterval = function () {
        var liRiskScore = $("#riskAssessmentScore").val();
        $.each(moConfig.JourneyCheckinIntervals, function (i, interval) {
            if (interval.StartScore <= liRiskScore) {
                moJourney.checkin_interval = interval.Minutes;
            }
            else {
                return;
            }
        });
        //set default if not set based on risk score
        if (!moJourney.checkin_interval) {
            moJourney.checkin_interval = 120;  
        }
        $("#txtCheckinInterval").val(Math.floor(moJourney.checkin_interval / 60.0) + " hr  " + moJourney.checkin_interval % 60 + " min");
    }

    var noGeolocationResponse = function () {
        $.mobile.loading("hide");
        enableDisableButtons(true);
        messageBox.show("Unable to get current position - no repsonse from location services. You will have to manually specify departure location.", "Get Current Location");
    }

    var populateEmployeeFields = function () {
        var loEmployee = JSON.parse(localStorage.Employee);
        moJourney.employee_id = loEmployee.employee_id;
        var lcEmployeeName = loEmployee.first_name + " " + loEmployee.last_name;
        $("#lblEmployeeName4").html(lcEmployeeName);
        $("#txtCellNumber4").val(loEmployee.cell_number);
        $("#txtEmailAddress4").val(loEmployee.email_address);
    }

    var populateVehicleFields = function () {
        var loVehicle = JSON.parse(localStorage.Vehicle);
        $("#txtUnitID4").val(loVehicle.vehicle_unit_id);
        $("#txtAvlSystem4").val(loVehicle.avl_system);
        $("#txtVehicleColor4").val(loVehicle.vehicle_color);
        $("#txtVehicleYear4").val((loVehicle.vehicle_year || 0 > 1900) ? loVehicle.vehicle_year.toString() : "");
        $("#txtVehicleMake4").val(loVehicle.vehicle_make);
        $("#txtVehicleModel4").val(loVehicle.vehicle_model);
        $("#txtVehicleLicensePlate4").val(loVehicle.vehicle_license_plate);
    }

    var populateEmployeeContactFields = function () {
        $("#lstEmergencyContacts4").empty();
        var lcolEmployeeContacts = JSON.parse(localStorage.EmployeeContacts);
        $.each(lcolEmployeeContacts, function (i, rec) {
            var lcItem = "<li class='ui-field-contain'>" +
                         "<h2>" + rec.contact_name + "</h2>" +
                         "<label>" + rec.phone_type_1 + ":" + rec.phone_number_1 + "</label>" +
                         "</li>"
            $("#lstEmergencyContacts4").append(lcItem);
        });
        $("#lstEmergencyContacts4").listview("refresh");
    }

    var commitInputFields = function () {

        var ldNow = new Date();
        moJourney.departure_datetime = dateToUtcString(ldNow);

        moJourney.destination_contact = $("#txtDestinationContactName").val();
        moJourney.destination_phone = $("#txtDestinationContactPhone").val();
        moJourney.duration_hours = $("#txtDurationHours2").val();
        moJourney.duration_minutes = $("#txtDurationMinutes2").val();
        updateEta();
        if (isDate($("#txtEta").val())) {
            var ldEta = new Date($("#txtEta").val());
            moJourney.eta = dateToUtcString(ldEta);
        }

        if (moConfig.RecordRiskScore) {
            moJourney.journey_risk_score = $("#riskAssessmentScore").val();
        }
        moJourney.vehicle_unit_id = $("#txtUnitID4").val();
        moJourney.avl_system = $("#txtAvlSystem4").val();
        moJourney.vehicle_color = $("#txtVehicleColor4").val();
        moJourney.vehicle_year = $("#txtVehicleYear4").val();
        moJourney.vehicle_make = $("#txtVehicleMake4").val();
        moJourney.vehicle_model = $("#txtVehicleModel4").val();
        moJourney.vehicle_license_plate = $("#txtVehicleLicensePlate4").val();
    }

    // get Me data
    var getEmployee = function () {
        if (localStorage.Employee) {
            populateEmployeeFields();
        }
    }

    // get vehicle
    var getVehicle = function () {
        if (localStorage.Vehicle) {
            populateVehicleFields();
        }
    }

    // get employee contacts
    var getEmployeeContacts = function () {
        if (localStorage.EmployeeContacts) {
            populateEmployeeContactFields();
        }
    }

    var saveRecord = function () {
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/journeys");
        $.ajax({
	        type: "POST",
            url: lcApiUri,
            data: moJourney
        }).always(function () {
            $.mobile.loading("hide");
        }).done(function (){
		    SetButtonVisibility();
            $.mobile.pageContainer.pagecontainer("change", "JourneyPage.html", { changeHash: false });
        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Create New Journey");
        });
    }

    // get active journey ID
    var getActiveJourneyID = function () {
        var lcApiUri = getApiUri("api/journeys/active/journeyid");
        $.getJSON(lcApiUri)
            .always(function() {
                enableDisableButtons(true);
                $.mobile.loading("hide");
            })
            .done(function (data) {
                if ((data || 0) > 0) {
                    vdis.ActiveJourneyID = data;
                  SetButtonVisibility();
                  $.mobile.back();
                }
                else {
                    vdis.ActiveJourneyID = 0; //indicates that there is no active journey
                    loadConfig();
                }
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Journey ID");
            });
    }

    // load journey management config
    var loadConfig = function () {
        var lcApiUri = getApiUri("api/journeys/config");
        $.getJSON(lcApiUri)
            .always(function () {
                enableDisableButtons(true);
                $.mobile.loading("hide");
            })
            .done(function (data) {
                moConfig = data;
                if (moConfig.RecordRiskScore) {
//                    $("#riskAssessmentScore").attr("min", moConfig.JraMinScore);
//                    $("#riskAssessmentScore").attr("max", moConfig.JraMaxScore);
                }
                else {
                    $("#riskAssessmentSection").hide();
                    moJourney.journey_risk_score = 0;
                }
                setCheckinInterval();
                load();
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Load Config");
            });
    }



    // --- main ---

    enableDisableButtons(false);
    getActiveJourneyID();

    var load = function () {

        if (!navigator.geolocation) {
            messageBox.show("Location services are not available in your browser. You will have to enter departure location manually.", "Current Location");
        }
        enableDisableButtons(true);

        if (!moJourney.departure_area) {

            $.mobile.loading("show");

            var loWaitForLocationServices = setTimeout(noGeolocationResponse, 15000);

            // get current location
            navigator.geolocation.getCurrentPosition(function (position) {
                clearTimeout(loWaitForLocationServices);
                $.mobile.loading("hide");
                $("#txtDeparture2").html(position.coords.latitude.toFixed(4) + ", " + position.coords.longitude.toFixed(4));
                moJourney.departure_latitude = position.coords.latitude;
                moJourney.departure_longitude = position.coords.longitude;

                //reverse geocode location
               var loLatLon = { lat: moJourney.departure_latitude, lon: moJourney.departure_longitude };
                var loGeocoder = L.mapbox.geocoder('mapbox.places');
                loGeocoder.reverseQuery(loLatLon, function (err, data) {
                    enableDisableButtons(true);
                    if (data) {
                        moJourney.departure_area = getFormattedAddress(data);
                        var lcDepartureText = vdis.newJourneyPage.data.departure_area
                        if ($("#txtDeparture2").html()) {
                            lcDepartureText += "<br />" + $("#txtDeparture2").html();
                        }
                        $("#txtDeparture2").html(lcDepartureText);
                    }
                });

            }, function (error) {
                clearTimeout(loWaitForLocationServices);
                $.mobile.loading("hide");
                var lcMessage = getCurrentPositionErrorMessage(error);
                messageBox.show(lcMessage, "Get Current Location");
            }, { maximumAge: 0, enableHighAccuracy: true, timeout: 10000 });

        }
        else {
            var lcDepartureText = moJourney.departure_area;
            var lnLatitude = parseFloat(moJourney.departure_latitude);
            var lnLongitude = parseFloat(moJourney.departure_longitude);
            if (!isNaN(lnLatitude) && !isNaN(lnLongitude)) {
                lcDepartureText += "<br />" + moJourney.departure_latitude.toFixed(4) + ", " + moJourney.departure_longitude.toFixed(4);
            }
            $("#txtDeparture2").html(lcDepartureText);
        }

        var ldNow = new Date();
        $("#txtStartTime").val(dateToDateTimeString(ldNow));

        var lcDestinationText = moJourney.destination_area;
        if (moJourney.destination_latitude && moJourney.destination_longitude) {
            lcDestinationText += "<br />" + moJourney.destination_latitude.toFixed(4) + ", " + moJourney.destination_longitude.toFixed(4);
        }
        $("#txtDestination2").html(lcDestinationText);
        $("#txtDestinationContactName").val(moJourney.destination_contact);
        $("#txtDestinationContactPhone").val(moJourney.destination_phone);

        var liDurationHours = 0;
        var liDurationMinutes = 0;
        if (moJourney.duration_hours) {
            liDurationHours = moJourney.duration_hours;
        }
        if (moJourney.duration_minutes) {
            liDurationMinutes = moJourney.duration_minutes;
        }
        if (liDurationHours > 0 || liDurationMinutes > 0) {
            $("#txtDurationHours2").val(moJourney.duration_hours).slider("refresh");
            $("#txtDurationMinutes2").val(moJourney.duration_minutes).slider("refresh");
            updateEta();
        }

        if (moJourney.journey_risk_score) {
            $("#riskAssessmentScore").val(riskScore);
        }


        getEmployee();
        getVehicle();
        getEmployeeContacts();

    }


    //--- event handlers ---


    $("#durationSection .ui-slider-input").on("slidestop", function (e, ui) {
        updateEta();
    });
    $("#durationSection .ui-slider-input").on("keyup", function (e, ui) {
        if (e.handled !== true) {
            e.handled = true;
            updateEta();
        }
    });
    
    
    $("#riskAssessmentScore").click(function() {
                                    checkJraThreshold();
                                    setCheckinInterval();
                                    
                                    });
    
//    $("#riskAssessmentSection .ui-slider-input").on("slidestop", function (e, ui) {
//        checkJraThreshold();
//        setCheckinInterval();
//    });
//    $("#riskAssessmentSection .ui-slider-input").on("keyup", function (e, ui) {
//        if (e.handled !== true) {
//            e.handled = true;
//            checkJraThreshold();
//            setCheckinInterval();
//        }
//    });
    
    
    

    $("#btnCopyPreviousJourney").click(function () {
        commitInputFields();
        vdis.previousJourneysPage.selectionMode = "Copy";
        $.mobile.pageContainer.pagecontainer("change", "PreviousJourneysPage.html");
    });

    $("#btnReversePreviousJourney").click(function () {
        commitInputFields();
        vdis.previousJourneysPage.selectionMode = "Reverse";
        $.mobile.pageContainer.pagecontainer("change", "PreviousJourneysPage.html");
    });

    $("#btnEditDeparture").click(function () {
        commitInputFields();
        $.mobile.pageContainer.pagecontainer("change", "EditDepartureLocationPage.html");
    });

    $("#btnEditDestination").click(function () {
        commitInputFields();
        $.mobile.pageContainer.pagecontainer("change", "EditDestinationLocationPage.html");
    });

    $("#btnEditMe2").click(function () {
        commitInputFields();
        $.mobile.pageContainer.pagecontainer("change", "MePage.html");
    });

    $("#btnEditVehicle2").click(function () {
        commitInputFields();
        $.mobile.pageContainer.pagecontainer("change", "MyVehiclePage.html");
    });

    $("#btnEditEmergencyContacts2").click(function () {
        commitInputFields();
        $.mobile.pageContainer.pagecontainer("change", "MyEmergencyContactsPage.html");
    });

    $("#btnSubmit").click(function () {
        commitInputFields();
        var lcolEmployeeContactsCount = JSON.parse(localStorage.EmployeeContacts);
                         
        //--- Validate

        //- required
        if (!(moJourney.departure_area && moJourney.departure_latitude && moJourney.departure_longitude)) {
            messageBox.show("Departure Location and Latitude/Longitude must be entered.", "Required");
            return;
        }
        if (!moJourney.destination_area) {
            messageBox.show("Destination Location must be entered.", "Required");
            return;
        }
        if (!moJourney.eta) {
            messageBox.show("ETA must be entered.", "Required");
            return;
        }
        if (moConfig.RecordRiskScore) {
        if (moJourney.journey_risk_score == null || moJourney.journey_risk_score == "" || moJourney.journey_risk_score == 0) {
            messageBox.show("Journey Risk Score must be entered.", "Required");
            return;
        }
        }
        if (!moJourney.vehicle_unit_id) {
            messageBox.show("Vehicle unit ID must be entered.", "Required");
            return;
        }
        if(lcolEmployeeContactsCount.length <1){
                        messageBox.show("Atleast one emergency contact must be present.", "Required");
                        return;
        }
        //- warning
        if (!(moJourney.destination_contact && moJourney.destination_phone)) {
            messageBox.show("Destination Contact Name and/or Phone are not entered.", "Warning", saveRecord, true);
            return;
        }

        saveRecord();
    });
}