﻿vdis.newMessagePage.loadPage = function () {

    var enableDisableButtons = function (enable) {
        if (enable) {
            $(".ui-btn").removeClass("ui-disabled");
        }
        else {
            $(".ui-btn").addClass("ui-disabled");
        }
    }

    // get active journey ID
    var getActiveJourneyID = function () {
        var lcApiUri = getApiUri("api/journeys/active/journeyid");
        $.getJSON(lcApiUri)
            .always(function () {
                enableDisableButtons(true);
            })
            .done(function (data) {
                vdis.ActiveJourneyID = (data || 0);
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Active Journey ID");
            });
    }



    //--- main ---

    enableDisableButtons(false);
    getActiveJourneyID();


    //--- event handlers ---


    $("#btnSend").click(function () {

        // Validate required fields
        if ($("#txtMessageText").val().trim() == '') {
            messageBox.show("Message text must be entered.", "Required");
            return;
        }

        var loTextMessage = {
            direction: "IN",
            journey_id: ((vdis.ActiveJourneyID || 0) > 0) ? vdis.ActiveJourneyID : null,
            message_text: $("#txtMessageText").val().trim()
        }

        // Send
        enableDisableButtons(false);
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/notifications/receive-inbound-message");
        $.ajax({
            type: "POST",
            url: lcApiUri,
            data: loTextMessage
        }).always(function () {
            $.mobile.loading("hide");
        }).done(function () {

            var ldNow = new Date();
            loTextMessage.action_datetime = dateToUtcString(ldNow);
            var mcolMessages = [];
            if (localStorage.Messages) {
                mcolMessages = JSON.parse(localStorage.Messages);
            }
            mcolMessages.splice(0, 0, loTextMessage);
            localStorage.Messages = JSON.stringify(mcolMessages);

            enableDisableButtons(true);
            // back to messages page
            $.mobile.back();

        }).fail(function (xhr, status, error) {
            messageBox.show(getAjaxErrorMessage(xhr, status, error), "Send Message");
        });

    });
}




