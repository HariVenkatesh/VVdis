vdis.previousJourneysPage.loadPage = function () {

    var mcolPreviousJourneys = [];
    if (localStorage.PreviousJourneys) {
        mcolPreviousJourneys = JSON.parse(localStorage.PreviousJourneys);
    }

    var getThumbImageName = function (isFavorite) {
        if (isFavorite) {
            return "favorite-thumb.png";
        }
        else {
            return "transparent-thumb.png";
        }
    }

    var populatePreviousJourneyList = function (filter) {
        $("#lstPreviousJourneys").empty();
        $.each(mcolPreviousJourneys, function (i, rec) {
            if (filter == "All" || rec.IsFavorite) {
                var lcThumbImageName = getThumbImageName(rec.IsFavorite);
                var lcItem = "<li id='item" + i + "' class='ui-btn' style='padding-left:40px'>" +
                             "<img src='Content/images/vdis-icons/" + lcThumbImageName + "' >" +
                             "<h2 style='white-space:pre-wrap'>" + rec.departure_area + " to " + rec.destination_area + "</h2>" +
                             "<label style='white-space:pre-wrap'>" + utcStringToDateTimeString(rec.departure_datetime) + " to " + utcStringToDateTimeString(rec.eta) + "</label>" +
                             "</li>"
                $("#lstPreviousJourneys").append(lcItem);
            }
        });
        $("#lstPreviousJourneys").listview("refresh");
    }

    var getPreviousJourneys = function () {
        $.mobile.loading("show");
        var lcApiUri = getApiUri("api/journeys/previous/20");
        $.getJSON(lcApiUri)
            .done(function (data) {
                localStorage.PreviousJourneys = JSON.stringify(data);
                localStorage.HasDownloadedPreviousJourneys = true;
                mcolPreviousJourneys = data;
                populatePreviousJourneyList("All");
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Get Previous Journeys");
            }).always(function () {
                $.mobile.loading("hide");
            });
    }

    var copyPreviousJourney = function (selectedItem) {
        vdis.newJourneyPage.data = {};
        vdis.newJourneyPage.data.employee_id = selectedItem.employee_id;
        vdis.newJourneyPage.data.vehicle_unit_id = selectedItem.vehicle_unit_id;
        vdis.newJourneyPage.data.vehicle_make = selectedItem.vehicle_make;
        vdis.newJourneyPage.data.vehicle_model = selectedItem.vehicle_model;
        vdis.newJourneyPage.data.vehicle_year = selectedItem.vehicle_year;
        vdis.newJourneyPage.data.vehicle_color = selectedItem.vehicle_color;
        vdis.newJourneyPage.data.vehicle_license_plate = selectedItem.vehicle_license_plate;
        vdis.newJourneyPage.data.avl_system = selectedItem.avl_system;
        vdis.newJourneyPage.data.destination_area = selectedItem.destination_area;
        vdis.newJourneyPage.data.destination_contact = selectedItem.destination_contact;
        vdis.newJourneyPage.data.destination_phone = selectedItem.destination_phone;
        vdis.newJourneyPage.data.destination_latitude = selectedItem.destination_latitude;
        vdis.newJourneyPage.data.destination_longitude = selectedItem.destination_longitude;
        if (vdis.previousJourneysPage.selectionMode == "Normal") {
            $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
        }
        else {
            $.mobile.back();
        }
    }

    var reversePreviousJourney = function (selectedItem) {
        vdis.newJourneyPage.data = {};
        vdis.newJourneyPage.data.employee_id = selectedItem.employee_id;
        vdis.newJourneyPage.data.vehicle_unit_id = selectedItem.vehicle_unit_id;
        vdis.newJourneyPage.data.vehicle_make = selectedItem.vehicle_make;
        vdis.newJourneyPage.data.vehicle_model = selectedItem.vehicle_model;
        vdis.newJourneyPage.data.vehicle_year = selectedItem.vehicle_year;
        vdis.newJourneyPage.data.vehicle_color = selectedItem.vehicle_color;
        vdis.newJourneyPage.data.vehicle_license_plate = selectedItem.vehicle_license_plate;
        vdis.newJourneyPage.data.avl_system = selectedItem.avl_system;
        vdis.newJourneyPage.data.destination_area = selectedItem.departure_area;
        vdis.newJourneyPage.data.destination_latitude = selectedItem.departure_latitude;
        vdis.newJourneyPage.data.destination_longitude = selectedItem.departure_longitude;
        if (vdis.previousJourneysPage.selectionMode == "Normal") {
            $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
        }
        else {
            $.mobile.back();
        }
    }


    //--- main ---


    if (localStorage.HasDownloadedPreviousJourneys || false) {
        populatePreviousJourneyList("All");
    }
    else {
        getPreviousJourneys();
    }


    //--- event handlers and actions ---


    // When a tab button is pressed, toggle favs on and off
    $(".previousJourneysPageTabs a").click(function () {
        var lcTabName = this.id.substring(3);  // button name minus the prefix
        populatePreviousJourneyList(lcTabName);
    });

    $("#lstPreviousJourneys").on("click", "li", function (e) {

        if (e.handled !== true) {
            e.handled = true;
        }
        else {
            return;
        }

        var lcSelectedItemID = this.id;
        var liItemIndex = parseInt(lcSelectedItemID.substring(4));
        var loSelectedItem = mcolPreviousJourneys[liItemIndex]
        switch (vdis.previousJourneysPage.selectionMode) {
            case "Normal":
                if (loSelectedItem.IsFavorite) {
                    $("#mnuFavorite").html("Unmark as Favorite");
                }
                else {
                    $("#mnuFavorite").html("Mark as Favorite");
                }
                $("#menuTitle").html(loSelectedItem.departure_area + " to " + loSelectedItem.destination_area)
                $("#popupMenu").popup("option", "positionTo", "#" + lcSelectedItemID);
                $("#popupMenu").popup("open");

                $("#lstMenuItems").off("click").on("click", "li", function (e) {

                    var lcSelectedMenuID = this.id;
                    switch (lcSelectedMenuID) {
                        case "mnuCopy":
                            copyPreviousJourney(loSelectedItem);
                            break;
                        case "mnuReverse":
                            reversePreviousJourney(loSelectedItem);
                            break;
                        case "mnuFavorite":
                            $("#popupMenu").popup("close");
                            // toggle favorite flag
                            loSelectedItem.IsFavorite = !loSelectedItem.IsFavorite;
                            localStorage.PreviousJourneys = JSON.stringify(mcolPreviousJourneys);
                            var lcThumbImageName = getThumbImageName(loSelectedItem.IsFavorite);
                            $("#" + lcSelectedItemID + " > img").attr("src", "Content/images/vdis-icons/" + lcThumbImageName);
                            $("#lstPreviousJourneys").listview("refresh");
                            break;
                        case "mnuCancel":
                            $("#popupMenu").popup("close");
                            break;
                    }

                });
                break;        
            case "Copy":
                copyPreviousJourney(loSelectedItem);
                break;
            case "Reverse":
                reversePreviousJourney(loSelectedItem);
                break;
        }

    });
    
    
    $("#btnFavorites").click(function(){
                             if($("#lstPreviousJourneys li").length==0){
                             messageBox.show("No Favorite Journey Present", "Get Previous Journeys");
                             }
                             });

}
   

    





