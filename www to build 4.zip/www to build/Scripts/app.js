var CheckinStatus = 0;
var StandbyStatus = 1;
var ResumeStatus = 2;
var riskScore = 0;

var changeThemeColors = function () {
    if (localStorage.Account) {
        var loAccount = JSON.parse(localStorage.Account);
        
        if (loAccount.company_branding != null) {
            var loPageBackgroudColor = (loAccount.company_branding.page_background_color);
            var loPageForegroudColor = (loAccount.company_branding.page_foreground_color);
            var loToolbarBackgroudColor = (loAccount.company_branding.toolbar_background_color);
            var loToolbarForegroudColor = (loAccount.company_branding.toolbar_foreground_color);
            var loHeaderBackgroudColor = (loAccount.company_branding.header_background_color);
            var loHeaderForegroudColor = (loAccount.company_branding.header_foreground_color);
            var loSectionBackgroudColor = (loAccount.company_branding.section_background_color);
            var loSectionForegroudColor = (loAccount.company_branding.section_foreground_color);
            
            /* change datarole=page background and Foreground Colors*/
            if (loPageBackgroudColor != null) {
                $('.ui-content').css('background-color', loPageBackgroudColor);
                $('.ui-page').css('background-color', loPageBackgroudColor);
            }
            else
            {
                $('.ui-content').css('background-color', '#f9f9f9');
                $('.ui-page').css('background-color', '#f9f9f9');
            }
            if (loPageForegroudColor != null) {
                $('.ui-content').css('color', loPageForegroudColor);
                $('.ui-page').css('color', loPageForegroudColor);
            }
            else
            {
                $('.ui-content').css('color', 'black');
                $('.ui-page').css('color', 'black');
            }
            
            if (loToolbarBackgroudColor != null) {
                $('.ui-link').css('background-color', loToolbarBackgroudColor);
                $('p .ui-link').css('background-color', 'white');
            }
            else
            {
                $('.ui-link').css('background-color', 'white');
                $('p .ui-link').css('background-color', 'white');
            }
            if (loToolbarForegroudColor != null) {
                $('.ui-link').css('color', loToolbarForegroudColor);
                $('p .ui-link').css('color', 'blue');
            }
            else
            {
                $('.ui-link').css('color', 'blue');
                $('p .ui-link').css('color', 'blue');
            }
            
            /* change datarole=header background and Foreground Colors*/
            if (loHeaderBackgroudColor != null) {
                $('.ui-page-theme-a .ui-bar-inherit').css('background-color', loHeaderBackgroudColor);
            }
            else
            {
                $('.ui-page-theme-a .ui-bar-inherit').css('background-color', '#e9e9e9');
            }
            if (loHeaderForegroudColor != null) {
                $('.ui-page-theme-a .ui-bar-inherit').css('color', loHeaderForegroudColor);
            }
            else
            {
                $('.ui-page-theme-a .ui-bar-inherit').css('color', 'black');
            }
            
            /* change datarole=main background and Foreground Colors*/
            if (loSectionBackgroudColor != null) {
                $('.ui-bar').css('background-color', loSectionBackgroudColor);
            }
            else
            {
                $('.ui-bar').css('background-color', '#e9e9e9');
            }
            if (loSectionForegroudColor != null) {
                $('.ui-bar').css('color', loSectionForegroudColor);
            }
            else
            {
                $('.ui-bar').css('color', 'black');
            }
        }
        else
        {
            $('.ui-content').css('background-color', '#f9f9f9');
            $('.ui-page').css('background-color', '#f9f9f9');
            $('.ui-link').css('background-color', 'white');
            $('p .ui-link').css('background-color', 'white');
            $('.ui-link').css('color', 'blue');
            $('p .ui-link').css('color', 'blue');
            $('.ui-page-theme-a .ui-bar-inherit').css('background-color', '#e9e9e9');
            $('.ui-page-theme-a .ui-bar-inherit').css('color', 'black');
            $('.ui-bar').css('background-color', '#e9e9e9');
            $('.ui-bar').css('color', 'black');
        }
        //$('.ui-bar-a').css('background-color', '#FFFFFFFF');
    }
}

var vdis = {
    indexPage: {
        loadPage: function () { }   // page specific functions bound in page scripts
    },
    myProfilePage: {
        loadPage: function () { }
    },
    accountPage: {
        loadPage: function () { }
    },
    mePage: {
        loadPage: function () { }
    },
    myVehiclePage: {
        loadPage: function () { },
        populateVehicleFields: function () {}
        },
    myEmergencyContactsPage: {
        employeeContacts: {},
        loadPage: function() {}
    },
    editEmergencyContactPage: {
        editMode: "New",
        data: {},
        loadPage: function () { }
    },
    journeyPage: {
        loadPage: function () { }
    },
    checkinPage: {
        loadPage: function () { }
    },
    closeJourneyPage: {
        loadPage: function () { }
    },
    newJourneyPage: {
        data: {},
        loadPage: function () { }
    },
    editDepartureLocationPage: {
        loadPage: function () { }
    },
    editDestinationLocationPage: {
        loadPage: function () { }
    },
    previousJourneysPage: {
        selectionMode: "Normal",
        loadPage: function () { }
    },
    mapPage: {
        loadPage: function () { }
    },
    messagesPage: {
        loadPage: function () { }
    },
    newMessagePage: {
        loadPage: function () { }
    }
//    riskscorecardPage: {
//        loadPage: function () { }
//    }
};


// if user bookmarked the page and has not yet been to the home page, 
// redirect them to the home page to load session data
function PageCanChange(toPageID) {
    if (!vdis.key) {
        if (localStorage.Account) {
            var loAccount = JSON.parse(localStorage.Account);
            vdis.key = loAccount.authentication_key;
            if (!vdis.indexPageWasVisited || false) {
                vdis.indexPageWasVisited = true;
                if (toPageID != "indexPage") {
                    $.mobile.pageContainer.pagecontainer("change", "Index.html", { changeHash: false });
                    return false;
                }
            }
            return true;
        }
        else {
            $.mobile.pageContainer.pagecontainer("change", "AccountPage.html", { changeHash: false });
            return false;
        }
    }
    return true;
}


$(document).on("pagecontainercreate", function () {

    //delete localStorage.Account;
    //localStorage.clear();
    L.mapbox.accessToken = MapKey;
    
    if (!vdis.initialized || false) {

        $(":mobile-pagecontainer").on("pagecontainerbeforetransition", function (e, ui) {
            if (ui.toPage[0].id != "accountPage") {
                if (!PageCanChange(ui.toPage[0].id)) {
                    e.preventDefault();
                    return;
                }
            }
        });

        $(":mobile-pagecontainer").on("pagecontainertransition", function (e, ui) {
            currentPageID = ui.toPage[0].id;
            switch (ui.toPage[0].id) {
                case "indexPage":
                    vdis.indexPage.loadPage();
                    break;
                case "myProfilePage":
                    vdis.myProfilePage.loadPage();
                    break;
                case "accountPage":
                    vdis.accountPage.loadPage();
                    break;
                case "mePage":
                    vdis.mePage.loadPage();
                    break;
                case "myVehiclePage":
                    vdis.myVehiclePage.loadPage();
                    break;
                case "myEmergencyContactsPage":
                    vdis.myEmergencyContactsPage.loadPage();
                    break;
                case "editEmergencyContactPage":
                    vdis.editEmergencyContactPage.loadPage();
                    break;
                case "journeyPage":
                    vdis.journeyPage.loadPage();
                    break;
                case "checkinPage":
                    vdis.checkinPage.loadPage();
                    break;
                case "closeJourneyPage":
                    vdis.closeJourneyPage.loadPage();
                    break;
                case "newJourneyPage":
                    vdis.newJourneyPage.loadPage();
                    break;
                case "editDepartureLocationPage":
                    vdis.editDepartureLocationPage.loadPage();
                    break;
                case "editDestinationLocationPage":
                    vdis.editDestinationLocationPage.loadPage();
                    break;
                case "previousJourneysPage":
                    vdis.previousJourneysPage.loadPage();
                    break;
                case "mapPage":
                    vdis.mapPage.loadPage();
                    break;
                case "messagesPage":
                    vdis.messagesPage.loadPage();
                    break;
                case "newMessagePage":
                    vdis.newMessagePage.loadPage();
                    break;
//                case "riskscorecardPage":
//                    vdis.riskscorecardPage.loadPage();
//                    break;
            }
           changeThemeColors();
        });

        vdis.initialized = true;

    }

});















