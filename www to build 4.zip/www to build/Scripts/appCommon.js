function getBaseServicesAddress() {
    var lcScheme = window.location.protocol;
    if (lcScheme.indexOf("//") == -1) {
        lcScheme += "//";
    }
    var lcHost = window.location.host;
    var lcBaseServicesAddress = lcScheme + lcHost + AppPath;
    return lcBaseServicesAddress;
}

function getAbsoluteAppPath() {
    var lcScheme = window.location.protocol;
    if (lcScheme.indexOf("//") == -1) {
        lcScheme += "//";
    }
    var lcHost = window.location.host;
    var lcPathName = window.location.pathname;
    var liFileIndex = lcPathName.toLowerCase().indexOf("index.html");
    if (liFileIndex == lcPathName.length - 10) {
        lcPathName = lcPathName.substring(0, liFileIndex);
    }
    var lcAppPath = lcScheme + lcHost + lcPathName;
    return lcAppPath;
}

function getApiUri(query, noKey) {
    var lcBaseServicesAddress = localStorage.BaseServicesAddress;
    if (lcBaseServicesAddress.lastIndexOf("/") != lcBaseServicesAddress.length - 1) {
        lcBaseServicesAddress += "/";
    }
    var lcApiUri = lcBaseServicesAddress + query;
    if (!(noKey || false)) {
        lcApiUri += "?key=" + vdis.key;
    }
    return lcApiUri;
}

var messageBox = {
show: function (message, title, callback, hasCancelButton) {
    if (localStorage.Account) {
        var loAccount = JSON.parse(localStorage.Account);
        if (loAccount.company_branding != null) {
            var loHeaderBackgroudColor = (loAccount.company_branding.header_background_color);
            var loHeaderForegroudColor = (loAccount.company_branding.header_foreground_color);
        }
    }
    var lcPopup = '<div data-role="popup" data-history="false" id="messageboxPopup">' +
    '<div class="messageboxHeader" style="background-color:' + loHeaderBackgroudColor + ';" data-role="header">' + title + '</div>' +
    '<p>' + message + '</p>' +
    '<div class="messageboxFooter">' +
    '<input type="button" id="btnOK" value="OK" data-inline="true" />' +
    (hasCancelButton ? '<input type="button" id="btnCancel" value="Cancel" data-inline="true" />' : '') +
    '</div>' +
    '</div>'
    $.mobile.pageContainer.pagecontainer("getActivePage").append(lcPopup).trigger("create");
    $("#messageboxPopup").popup();
    $("#messageboxPopup").popup("option", "dismissible", false);
    $("#messageboxPopup").popup("open");
    $("#btnOK").on("click", function (e) {
                   e.preventDefault();
                   if (e.handled !== true) {
                   e.handled = true;
                   if (callback) {
                   callback(true);
                   }
                   $("#messageboxPopup").popup("close");
                   }
                   });
    $("#btnCancel").on("click", function (e) {
                       e.preventDefault();
                       if (e.handled !== true) {
                       e.handled = true;
                       if (callback) {
                       callback(false);
                       }
                       //$(document).trigger("messageBoxClosed", false);
                       $("#messageboxPopup").popup("close");
                       }
                       });
    $(document).off("popupafterclose", this.remove);  // unbind first to prevent multiple calls
    $(document).on("popupafterclose", this.remove);
},
remove: function() {
    $("#messageboxPopup").remove();
}
}

String.prototype.replaceAll = function (str1, str2, ignore) {
    return this.replace(new RegExp(str1.replace(/([\,\!\\\^\$\{\}\[\]\(\)\.\*\+\?\|\<\>\-\&])/g, function (c) { return "\\" + c; }), "g" + (ignore ? "i" : "")), str2);
};

function getAjaxErrorMessage(xhr, status, error) {
    var lcMessage = "Error has occurred";
    switch (xhr.status) {
        case 500:
            lcMessage = xhr.responseText.replaceAll("\r", "<br>");
            break;
        case 401:
            lcMessage = "Unauthorized access. Please reactivate this app.";
            break;
        default:
            lcMessage += ", xhr status: " + xhr.status;
            if (error) {
                lcMessage += ", error: " + error;
            }
            break;
    }
    return lcMessage;
}

function getCurrentPositionErrorMessage(error) {
    var lcMessage = "";
    // Check for known errors
    switch (error.code) {
        case error.PERMISSION_DENIED:
            lcMessage = "Permission to access current position was denied.";
            break;
        case error.POSITION_UNAVAILABLE:
            lcMessage = "The current position could not be determined.";
            break;
        case error.TIMEOUT:
            lcMessage = "The current position could not be determined within the specified timeout period.";
            break;
    }
    // If it's an unknown error, build a message that includes 
    // information that helps identify the situation, so that 
    // the error handler can be updated.
    if (lcMessage == "") {
        var strErrorCode = error.code.toString();
        lcMessage = "The position could not be determined due to an unknown error (Code: " + strErrorCode + ").";
    }
    return lcMessage;
}

function getFormattedAddress(reverseGeocodeResponse) {
    var lcAddress = "";
    if (reverseGeocodeResponse.features.length >=1) {
        if (reverseGeocodeResponse.features[0].address) {  //house number
            lcAddress = reverseGeocodeResponse.features[0].address.toString();
        }
        
        if (reverseGeocodeResponse.features[0].text) {  //road
            lcAddress += (lcAddress.length > 0 ? " " : "") + reverseGeocodeResponse.features[0].text;
        }
    }
    if (reverseGeocodeResponse.features.length >=2) {
        if (reverseGeocodeResponse.features[1].text) {  //city
            lcAddress += (lcAddress.length > 0 ? ", " : "") + reverseGeocodeResponse.features[1].text;
        }
    }
    if (reverseGeocodeResponse.features.length >=4) {
        if (reverseGeocodeResponse.features[3].text) {  //state
            lcAddress += (lcAddress.length > 0 ? ", " : "") + reverseGeocodeResponse.features[3].text;
        }
    }
    return lcAddress;
}

function repeatChar(char, times) {
    var lcResult = "";
    for (var i = 0; i < times; i++) {
        lcResult += char;
    }
    return lcResult;
}

function padNumericID(n, length) {
    if (n) {
        return String(repeatChar("0", length) + n).slice(length * -1);
    }
    else {
        return "";
    }
}

var gaMonthNamesShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function convertDateToUTC(date) {
    return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
}

function isDate(date) {
    return !isNaN(Date.parse(date));
}

function utcStringToDateTimeString(utcString) {
    if (isDate(utcString)) {
        var d = new Date(utcString);
        return dateToDateTimeString(d);
    }
    else {
        return "";
    }
}

function dateToDateTimeString(d) {
    var lcFormatted = dateToDateString(d) + ", " + dateToTimeString(d);
    return lcFormatted;
}

function dateToDateString(d) {
    var lcMonth = gaMonthNamesShort[d.getMonth()];
    var liDay = d.getDate();
    var liYear = d.getFullYear();
    var lcFormatted = lcMonth + " " + liDay + ", " + liYear;
    return lcFormatted;
}

function dateToTimeString(d) {
    var liHours = d.getHours();
    var liMinutes = d.getMinutes();
    var lcAmPm = liHours >= 12 ? 'pm' : 'am';
    liHours = liHours % 12;
    liHours = liHours ? liHours : 12; // the liHours '0' should be '12'
    liMinutes = liMinutes < 10 ? '0'+liMinutes : liMinutes;
    var lcFormatted = liHours + ":" + liMinutes + " " + lcAmPm;
    return lcFormatted;
}

function dateToUtcString(d) {
    return d.toISOString();
}

function SetButtonVisibility() {
    
    $("#btnWorkAlonePeriod").css("visibility", "hidden");
    $("#btnWorkAlonePeriod").css("display", "none");
    $("#btnJourneyHome").css("visibility", "hidden");
    $("#btnJourneyHome").css("display", "none");
    $("#btnPreviousHome").css("visibility", "hidden");
    $("#btnPreviousHome").css("display", "none");
    $("#btnArrivedHome").css("visibility", "hidden");
    $("#btnArrivedHome").css("display", "none");
    $("#btnMap").css("visibility", "hidden");
    $("#btnMap").css("display", "none");
    $("#btnMessages").css("visibility", "hidden");
    $("#btnMessages").css("display", "none");
    $("#btnMyProfile").css("visibility", "hidden");
    $("#btnMyProfile").css("display", "none");
    getLogoImage()
  }

//get logo image
function getLogoImage() {
    if (localStorage.Account) {
        var loAccount = JSON.parse(localStorage.Account);
        $("#logo").attr("src", "");
        if (loAccount.company_branding != null) {
            if (loAccount.company_branding.logo_image_url != null) {
                $("#logo").attr("src", loAccount.company_branding.logo_image_url);
            }
        }
    }
}

Date.prototype.diffMinutes = function(endDate) {
    var liStartMsec = this.getTime();
    var liEndMsec = endDate.getTime();
    var liDiffMsec = liEndMsec - liStartMsec;
    var liDiffSeconds = parseInt(liDiffMsec / 1000);
    var liDiffMinutes = parseInt(liDiffSeconds / 60);
    return liDiffMinutes;
}

Date.prototype.addMinutes = function (n) {
    var MillisecondsPerMinute = 60 * 1000;
    var liMillisecondsToAdd = n * MillisecondsPerMinute;
    return new Date(this.getTime() + liMillisecondsToAdd);
}

Array.prototype.insert = function(index, item) {
    this.splice(index, 0, item);
}

Array.prototype.removeAt = function (index) {
    this.splice(index, 1);
}

/*-- Common Method To Show Loading Icon While Calling Webservice  --*/

