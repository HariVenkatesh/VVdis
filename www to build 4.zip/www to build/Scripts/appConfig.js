var BaseServicesAddressDict = [];

BaseServicesAddressDict["WFT"] = "https://vdis.ca.weatherford.com/mobile.webapp";
BaseServicesAddressDict["WFTLA"] = "https://vdis.ca.weatherford.com/la/mobile.webapp";
var testServiceURL = "https://live.vdis.com/test/mobile.webapp";
BaseServicesAddressDict["DOTEST"] = testServiceURL;
BaseServicesAddressDict["GOLDTEST"] = testServiceURL;
BaseServicesAddressDict["LIVE"] = "https://live.vdis.com/mobile.webapp";

var AppVersion = "1.1.2";

var MapKey = 'pk.eyJ1IjoidG9ueWx1Z2ciLCJhIjoiY2lnMmd2eDIzMWNvMnRya3dtMmRvdDk5cCJ9._R2NMFjCsK6p-Vj6zFhRgg';
