var pushNotification;
var currentPageID;
var OldLatitude = 0.0;
var OldLongitude = 0.0;

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    StatusBar.overlaysWebView(false);
    StatusBar.styleDefault();
    if ( device.platform != 'android' && device.platform != 'Android' ){
      StatusBar.backgroundColorByHexString("#E9E9E9");
    }
    pushNotification = window.plugins.pushNotification;
    registerForPushNotification();
  
    /* Code To Initiate Disable While Moving
       setInterval(function() {
                   navigator.geolocation.getCurrentPosition(geolocationSuccess,geolocationError);
                    }, 600000);
 */
}

/* Code To Disable While Moving*/

function geolocationSuccess(position){
    
    if(OldLatitude == 0.0){
        OldLatitude = position.coords.latitude;
        OldLongitude = position.coords.longitude;
    }else{
        
        //        console.log("getDistanceFromLatLonInKm"+position.coords.latitude+"-long-"+position.coords.longitude+"-OldLatitude-"+OldLatitude+"-OldLongitude-"+OldLongitude);
        
        var distance = getDistanceFromLatLonInKm(position.coords.latitude,position.coords.longitude,OldLatitude, OldLongitude);
        
        console.log('distance is ---- '+distance);
        
        if(distance>5000) /* if vechcle moves 5 km app will get locked*/
        {
            applock();
            
        }else{
            $("body").unbind("touchmove");
            $(".modalWindow").remove();
            $.mobile.loading("hide");
            //  alert("distance");
            //applock();
        }
        OldLatitude = position.coords.latitude;
        OldLongitude = position.coords.longitude;
        //        console.log("coords"+OldLatitude+""+OldLongitude);
    }
    
}


function geolocationError(e){
    alert("error"+JSON.stringify(e));
}

function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
    
    console.log("asdf"+lat1+""+lon1+"-----"+lat2+""+lon2)
    LatLng = lat1+""+lon1;
    LatLng2 = lat2+""+lon2;
    
    var R = 6371; // km (change this constant to get miles)
    var dLat = (lat2-lat1) * Math.PI / 180;
    var dLon = (lon2-lon1) * Math.PI / 180;
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180 ) * Math.cos(lat2 * Math.PI / 180 ) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
    console.log("a"+a)
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    console.log("c"+c);
    var d = R * c;
    console.log("d"+d);
    //    if (d>1) return Math.round(d)+"km";
    //    else if (d<=1) return Math.round(d*1000)+"m";
    if (d>1){
        
        return Math.round(d);
    }
    else if (d<=1){
        return Math.round(d*1000);
    }
    console.log("ddddd"+d)
    return d;
}


function applock(){
    $("body").append("<div class='modalWindow'/>");
    $("body").bind("touchmove", function(e) {
                   e.preventDefault()
                   });
    $.mobile.loading("show", {
                     text: "App Locked...",
                     textVisible: true,
                     theme: "a",
                     html: ""
                     });
    
}

/* End Of function */

// Register For PushNotification in GCM/APNS
var registerForPushNotification = function () {
    localStorage.deviceToken = '';
    if ( device.platform == 'android' || device.platform == 'Android' ){
	    pushNotification.register(
	    successHandler,
	    errorHandler,
	    {
	        "senderID":"382788495739", // Project Number
	        "ecb":"onNotification"
	    });
	} else {
	    pushNotification.register(
	    tokenHandler,
	    errorHandler,
	    {
	        "badge":"true",
	        "sound":"true",
	        "alert":"true",
	        "ecb":"onNotificationAPN"
	    });
	}
}

var tokenHandler = function (result) {
    // Your iOS push server needs to know the token before it can push to this device 
    localStorage.deviceToken = result;
}

// result contains any message sent from the plugin call 
var successHandler = function (result) {
  
}

// result contains any error description text returned from the plugin call 
var errorHandler = function (error) {
  
}

// iOS 
var onNotificationAPN = function (event) {
    
  if ( event.foreground == "1" )
  {
      if ( event.alert )
      {
         messageBox.show("Want to veiw now?", "New Message Received",
                function (okPressed) {
                  if (okPressed) {
                    if (currentPageID == 'messagesPage') {
                        vdis.messagesPage.loadPage();
                    }else if(currentPageID == 'newMessagePage'){
                        $.mobile.back();
                    } else{
                        $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
                    };
                  };
                }, true);
      } 
      if ( event.badge )
      {
        pushNotification.setApplicationIconBadgeNumber(successHandler, errorHandler, event.badge);
      }
  } else {
    $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
  }
}

// Android
var onNotification = function (e) { 
  switch( e.event )
  {
  case 'registered':
    if ( e.regid.length > 0 )
    {
      // Your GCM push server needs to know the regID before it can push to this device 
      localStorage.deviceToken = e.regid;
    }
  break;
 
  case 'message':
    // if this flag is set, this notification happened while we were in the foreground. 
    // you might want to throw up a dialog to get the user's attention, etc. 
    if ( e.foreground )
    {
      if ( e.payload.message )
      {
         messageBox.show("Want to veiw now?", "New Message Received",
                function (okPressed) {
                  if (okPressed) {
                    if (currentPageID == 'messagesPage') {
                        vdis.messagesPage.loadPage();
                    }else if(currentPageID == 'newMessagePage'){
                        $.mobile.back();
                    } else{
                        $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
                    };
                  };
                }, true);
      }       
    }
    else
    {  // otherwise we were launched because the user touched a notification in the notification tray. 
      if ( e.coldstart )
      {
        $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
      }
      else
      {
        $.mobile.pageContainer.pagecontainer("change", "MessagesPage.html");
        //BACKGROUND NOTIFICATION;
      }
    }
  break;
 
  case 'error':
  break;
 
  default:
  break;
  }
}

var registerDevice = function (isReactivating) {
  if (localStorage.deviceToken.length == 0) {
    messageBox.show("Please turn on pushnotification in settings and reactivate the app", "Register For Notifications",
      function (okPressed) {
                    if (isReactivating) {
                    SetButtonVisibility();
                    $.mobile.back();
                    }
                    else{
                    location.reload(true);
                    }
      },false);
  } else{
      
    var loDeviceToken = {
            token: localStorage.deviceToken,
        };
     $.mobile.loading("show", { text: "Registering Device....", textVisible: true });
     var lcApiUri = getApiUri("api/notifications/register");
            $.ajax({
                type: "POST",
                url: lcApiUri,
                data: loDeviceToken
            }).always(function () {
                $.mobile.loading("hide");
            }).done(function (data) {
                    if (isReactivating) {
                    SetButtonVisibility();
                    $.mobile.back();
                    }
                    else{
                    location.reload(true);
                    }
            }).fail(function (xhr, status, error) {
                messageBox.show(getAjaxErrorMessage(xhr, status, error), "Register For Notifications");
            });
    }
  }
