var questions;

$("#riskscorecardPage").on("pagecreate",function(){
          
 
 questions = [];
 questions = [ "Do you like music?", "Do you like cricket?", "is he working very hard?", "Do you like music?", "Do you like cricket?", "he working very hard?","Do you like music?", "Do you like cricket?", "he working very hard?"];


$("#riskScoreCardQuestionsListView").empty();
for(var i=1;i<questions.length;i++){
$("#riskScoreCardQuestionsListView").append("<li><div style='width:100% !important;'><div class='riskScoreCardPgQuestionNo'>"+i+")</div>\
                                            <div class='riskScoreCardPgQuestions'>"+questions[i]+"</div>\
                                            <div class='riskScoreCardPgFlipSwitch'>\
                                            <div style='float:right !important'>\
                                            <select class='' id='riskScoreFlipSwitch"+i+"' data-role='slider'>\
                                            <option value='0'>No</option>\
                                            <option value='1'>Yes</option>\
                                            </select></div></div>\
                                            </div></li>");
}
                  
$("#riskScoreCardQuestionsListView").listview("refresh");

}); 

function calculateRiskScore(){
    riskScore = 0;
    for(var i=1;i<questions.length;i++){
        if($("#riskScoreFlipSwitch"+i).val() == "1"){
            riskScore = riskScore+1;
    }
}
  $.mobile.pageContainer.pagecontainer("change", "NewJourneyPage.html");
}

